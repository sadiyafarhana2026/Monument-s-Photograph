import express from 'express';
import path from 'path';
import dotenv from 'dotenv';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';
import { dbStore } from './src/db_store.js';

// Load environment variables
dotenv.config();

const app = express();
const PORT = 3000;

// Increase payload limits for handling base64 image uploads
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ limit: '50mb', extended: true }));

// Lazy initializer for Gemini client
let geminiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI {
  if (!geminiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error('GEMINI_API_KEY environment variable is not set. Please set it in Settings > Secrets.');
    }
    geminiClient = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return geminiClient;
}

// REST APIs for Auth
app.post('/api/auth/login', (req, res) => {
  const { username, password } = req.body;
  if (!username) {
    res.status(400).json({ error: 'Username is required' });
    return;
  }

  const users = dbStore.getUsers();
  // Simple check: if password is 'admin' or same as username
  const user = users.find(u => u.username.toLowerCase() === username.toLowerCase());
  
  if (user) {
    res.json({ user, token: `demo-token-${user.id}` });
  } else {
    // Auto-create user for frictionless demo if not exist
    const newUser = {
      id: `user-${Date.now()}`,
      username: username,
      email: `${username}@example.com`,
      fullName: username.charAt(0).toUpperCase() + username.slice(1),
      role: (username === 'admin' ? 'admin' : 'user') as 'admin' | 'user',
      createdAt: new Date().toISOString()
    };
    dbStore.addUser(newUser);
    res.json({ user: newUser, token: `demo-token-${newUser.id}` });
  }
});

app.post('/api/auth/register', (req, res) => {
  const { username, email, fullName } = req.body;
  if (!username || !email || !fullName) {
    res.status(400).json({ error: 'All fields (username, email, fullName) are required' });
    return;
  }

  const users = dbStore.getUsers();
  const existing = users.find(u => u.username.toLowerCase() === username.toLowerCase() || u.email.toLowerCase() === email.toLowerCase());
  
  if (existing) {
    res.status(400).json({ error: 'Username or email already exists. Try logging in!' });
    return;
  }

  const newUser = {
    id: `user-${Date.now()}`,
    username,
    email,
    fullName,
    role: (username === 'admin' ? 'admin' : 'user') as 'admin' | 'user',
    createdAt: new Date().toISOString()
  };

  dbStore.addUser(newUser);
  res.json({ user: newUser, token: `demo-token-${newUser.id}` });
});

app.post('/api/auth/profile', (req, res) => {
  const { id, fullName, email } = req.body;
  if (!id) {
    res.status(400).json({ error: 'User ID is required' });
    return;
  }

  const updated = dbStore.updateUser(id, { fullName, email });
  if (updated) {
    res.json({ success: true, user: updated });
  } else {
    res.status(404).json({ error: 'User not found' });
  }
});

// AI Prediction Route
app.post('/api/predict', async (req, res) => {
  const { imageBase64, userId, mimeType } = req.body;
  const activeUserId = userId || 'user-1';

  if (!imageBase64) {
    res.status(400).json({ error: 'No image data supplied.' });
    return;
  }

  // Ensure base64 carries clean payload
  const cleanBase64 = imageBase64.replace(/^data:image\/\w+;base64,/, '');
  const activeMimeType = mimeType || 'image/png';

  try {
    const ai = getGeminiClient();

    const systemPrompt = `You are an expert AI art historian and travel guide. 
Your task is to analyze the provided monument image and recognize the monument.
If the image does NOT contain a monument, try to identify what it is, but provide the data in the same JSON format representing the details of the nearest relevant physical landmark, architectural work, or standard monument.
Always return your response strictly as a JSON object matching the requested schema.`;

    const userPrompt = `Identify this monument from the image. Provide:
1. monumentName: Name of the monument (e.g. Taj Mahal, Eiffel Tower, etc.).
2. confidence: Estimated model recognition confidence percentage (number between 50 and 100).
3. country: Country where it is located.
4. location: City, State/Region or specific address coordinates.
5. history: Engaging 2-3 paragraph historical background, origins, construct story.
6. architectureStyle: Architectural design style (e.g., Mughal, Gothic Gothic Revival, Romanesque).
7. famousFacts: Array of 3 to 4 famous facts or hidden secrets about it.
8. constructionYear: Approximate year or century of completion/commissioning (e.g., 1648, 12th Century).
9. touristImportance: Significance for modern tourism, best time to visit, and visitor interest points.`;

    const imagePart = {
      inlineData: {
        mimeType: activeMimeType,
        data: cleanBase64,
      },
    };

    const textPart = {
      text: userPrompt,
    };

    const response = await ai.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: { parts: [imagePart, textPart] },
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            monumentName: { type: Type.STRING },
            confidence: { type: Type.NUMBER },
            country: { type: Type.STRING },
            location: { type: Type.STRING },
            history: { type: Type.STRING },
            architectureStyle: { type: Type.STRING },
            famousFacts: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
            constructionYear: { type: Type.STRING },
            touristImportance: { type: Type.STRING },
          },
          required: [
            'monumentName',
            'confidence',
            'country',
            'location',
            'history',
            'architectureStyle',
            'famousFacts',
            'constructionYear',
            'touristImportance',
          ],
        },
      },
    });

    if (!response.text) {
      throw new Error('No prediction text received from Gemini Vision service.');
    }

    const predictionData = JSON.parse(response.text.trim());

    // Make sure confidence resides within 0-100
    let conf = Math.round(Number(predictionData.confidence) || 90);
    if (conf < 0 || conf > 100) conf = 95;

    // Save this scan in history
    const finishedScan = {
      id: `scan-${Date.now()}`,
      userId: activeUserId,
      imagePath: imageBase64, // Persist base64 standard representation
      monumentName: predictionData.monumentName,
      confidence: conf,
      location: predictionData.location,
      country: predictionData.country,
      history: predictionData.history,
      architectureStyle: predictionData.architectureStyle,
      famousFacts: predictionData.famousFacts,
      constructionYear: predictionData.constructionYear,
      touristImportance: predictionData.touristImportance,
      timestamp: new Date().toISOString(),
    };

    dbStore.addScan(finishedScan);

    res.json(finishedScan);
  } catch (err: any) {
    console.error('API Prediction Failed:', err);
    res.status(500).json({
      error: 'Recognition service failed.',
      message: err.message || 'Unknown network error inside Gemini Vision handler.',
    });
  }
});

// Scan History Routes
app.get('/api/history', (req, res) => {
  const { userId } = req.query;
  const activeUserId = userId as string;
  const history = dbStore.getScans(activeUserId);
  res.json(history);
});

app.delete('/api/history/:id', (req, res) => {
  const { id } = req.params;
  dbStore.deleteScan(id);
  res.json({ success: true });
});

// Admin Managing routes
app.get('/api/admin/users', (req, res) => {
  res.json(dbStore.getUsers());
});

app.post('/api/admin/users/:id/role', (req, res) => {
  const { id } = req.params;
  const { role } = req.body;
  if (role !== 'admin' && role !== 'user') {
    res.status(400).json({ error: 'Invalid role' });
    return;
  }
  const updated = dbStore.updateUser(id, { role });
  res.json({ success: true, user: updated });
});

app.delete('/api/admin/users/:id', (req, res) => {
  const { id } = req.params;
  dbStore.deleteUser(id);
  res.json({ success: true });
});

app.get('/api/admin/dataset', (req, res) => {
  res.json(dbStore.getDataset());
});

app.post('/api/admin/dataset', (req, res) => {
  const { name, country, location, architectureStyle, constructionYear, description, facts, importance } = req.body;
  
  if (!name || !country || !location) {
    res.status(400).json({ error: 'Name, Country and Location are required' });
    return;
  }

  const newItem = {
    id: `data-${Date.now()}`,
    name,
    country,
    location,
    architectureStyle: architectureStyle || 'Unknown',
    constructionYear: constructionYear || 'N/A',
    description: description || '',
    facts: facts || [],
    importance: importance || '',
  };

  dbStore.addDatasetItem(newItem);
  res.json({ success: true, item: newItem });
});

app.put('/api/admin/dataset/:id', (req, res) => {
  const { id } = req.params;
  const updated = dbStore.updateDatasetItem(id, req.body);
  if (updated) {
    res.json({ success: true, item: updated });
  } else {
    res.status(404).json({ error: 'Item not found' });
  }
});

app.delete('/api/admin/dataset/:id', (req, res) => {
  const { id } = req.params;
  dbStore.deleteDatasetItem(id);
  res.json({ success: true });
});

// Start listening or initialize Vite engine
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Monument Vision AI Server booting on http://localhost:${PORT}`);
  });
}

startServer();
