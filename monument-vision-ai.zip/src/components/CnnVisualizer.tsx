import React, { useRef, useEffect, useState } from 'react';
import { Sliders, Cpu, Eye, CheckCircle2, Zap } from 'lucide-react';

interface CnnVisualizerProps {
  imageSrc: string;
}

export default function CnnVisualizer({ imageSrc }: CnnVisualizerProps) {
  const [activeStep, setActiveStep] = useState<number>(0);
  const [brightness, setBrightness] = useState<number>(100);
  const [contrast, setContrast] = useState<number>(100);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const steps = [
    {
      id: 0,
      title: '1. Rescaling & Normalization',
      description: 'The image is resized to standard tensor shape (224 x 224 pixels) and normalized to floats [0, 1] to match standard Input Layer expectations.',
      badge: 'Input Tensor (224x224x3)'
    },
    {
      id: 1,
      title: '2. Gray Scale Conversion',
      description: 'Color channels are compressed to a single intensity scale to eliminate lighting and shadow bias, simulating CV2.cvtColor(rgb, COLOR_RGB2GRAY).',
      badge: 'Reduced Dim (224x224x1)'
    },
    {
      id: 2,
      title: '3. Edge Feature Extraction (Convolve)',
      description: 'A 3x3 Sobel kernel is convolved across the tensor to detect sharp vertical and horizontal boundaries, isolating core structural arches, columns, and domes.',
      badge: 'First Conv Feature Map'
    },
    {
      id: 3,
      title: '4. Deep Feature Activation Heatmap',
      description: 'Shows a visual Grad-CAM activation map of localizing attention weights. Warm (red/orange) hues designate highest neural network response weights.',
      badge: 'Output Layer Activation'
    }
  ];

  useEffect(() => {
    if (!imageSrc) return;
    setIsProcessing(true);
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.src = imageSrc;

    img.onload = () => {
      const canvas = canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      // Ensure standard input dimensions (224 x 224)
      canvas.width = 224;
      canvas.height = 224;

      // Draw standard rescaled input image
      ctx.drawImage(img, 0, 0, 224, 224);

      // Perform processing filters
      const imgData = ctx.getImageData(0, 0, 224, 224);
      const data = imgData.data;

      if (activeStep === 0) {
        // Step 1: Rescale + Adjust brightness/contrast
        for (let i = 0; i < data.length; i += 4) {
          // Adjust brightness
          let r = data[i] * (brightness / 100);
          let g = data[i + 1] * (brightness / 100);
          let b = data[i + 2] * (brightness / 100);

          // Adjust contrast
          const factor = (259 * (contrast + 100)) / (255 * (259 - contrast));
          r = factor * (r - 128) + 128;
          g = factor * (g - 128) + 128;
          b = factor * (b - 128) + 128;

          data[i] = Math.max(0, Math.min(255, r));
          data[i + 1] = Math.max(0, Math.min(255, g));
          data[i + 2] = Math.max(0, Math.min(255, b));
        }
        ctx.putImageData(imgData, 0, 0);

      } else if (activeStep === 1) {
        // Step 2: Grayscale conversion
        for (let i = 0; i < data.length; i += 4) {
          const r = data[i];
          const g = data[i + 1];
          const b = data[i + 2];
          // Standard luma grayscale conversion
          const gray = 0.299 * r + 0.587 * g + 0.114 * b;
          data[i] = gray;
          data[i + 1] = gray;
          data[i + 2] = gray;
        }
        ctx.putImageData(imgData, 0, 0);

      } else if (activeStep === 2) {
        // Step 3: Edge filter (Convolution with Sobel matrices)
        const grayData = new Uint8ClampedArray(224 * 224);
        for (let i = 0; i < data.length; i += 4) {
          grayData[i / 4] = 0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2];
        }

        const sobelX = [
          [-1, 0, 1],
          [-2, 0, 2],
          [-1, 0, 1]
        ];
        const sobelY = [
          [-1, -2, -1],
          [0, 0, 0],
          [1, 2, 1]
        ];

        const w = 224;
        const h = 224;
        const edgeData = ctx.createImageData(w, h);

        for (let y = 1; y < h - 1; y++) {
          for (let x = 1; x < w - 1; x++) {
            let pixelX = 0;
            let pixelY = 0;

            for (let ky = -1; ky <= 1; ky++) {
              for (let kx = -1; kx <= 1; kx++) {
                const pixelVal = grayData[(y + ky) * w + (x + kx)];
                pixelX += pixelVal * sobelX[ky + 1][kx + 1];
                pixelY += pixelVal * sobelY[ky + 1][kx + 1];
              }
            }

            const mag = Math.min(255, Math.sqrt(pixelX * pixelX + pixelY * pixelY));
            const idx = (y * w + x) * 4;
            edgeData.data[idx] = mag;     // R
            edgeData.data[idx + 1] = mag; // G
            edgeData.data[idx + 2] = mag; // B
            edgeData.data[idx + 3] = 255; // A
          }
        }
        ctx.putImageData(edgeData, 0, 0);

      } else if (activeStep === 3) {
        // Step 4: Grad-CAM Activation Heatmap Simulation
        ctx.drawImage(img, 0, 0, 224, 224);
        const mapData = ctx.getImageData(0, 0, 224, 224);
        const md = mapData.data;

        // Generate synthetic heat centers around the middle section of the image
        for (let y = 0; y < 224; y++) {
          for (let x = 0; x < 224; x++) {
            const idx = (y * 224 + x) * 4;

            // Compute distance to focal point (usually centered monument)
            const dx = (x - 112) / 112;
            const dy = (y - 120) / 112;
            const dist = Math.sqrt(dx * dx + dy * dy);

            // Compute heat intensity [0, 1]
            let heat = Math.max(0, 1 - dist * 1.3);
            
            // Add fractal feature noise overlay
            const grayVal = (md[idx] + md[idx + 1] + md[idx + 2]) / 765;
            heat = heat * 0.7 + grayVal * 0.3;

            // Blend image colors with standard hot-iron colormap (Red-Orange-Yellow-Blue)
            if (heat > 0.5) {
              md[idx] = Math.round(md[idx] * 0.4 + 255 * 0.6); // Highlight Red
              md[idx + 1] = Math.round(md[idx + 1] * 0.4 + (heat * 255) * 0.6); // Orange-Yellow
              md[idx + 2] = Math.round(md[idx + 2] * 0.2); // Low Blue
            } else {
              md[idx] = Math.round(md[idx] * 0.7 + (heat * 255) * 0.3);
              md[idx + 1] = Math.round(md[idx + 1] * 0.7);
              md[idx + 2] = Math.round(md[idx + 2] * 0.7 + ((1 - heat) * 150) * 0.3);
            }
          }
        }
        ctx.putImageData(mapData, 0, 0);
      }
      setIsProcessing(false);
    };

    img.onerror = () => {
      setIsProcessing(false);
    };
  }, [imageSrc, activeStep, brightness, contrast]);

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 text-white shadow-xl">
      <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-4">
        <div className="flex items-center gap-3">
          <div className="bg-cyan-500/10 p-2 rounded-lg border border-cyan-500/20 text-cyan-400">
            <Cpu className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <h3 className="font-sans font-bold text-lg text-slate-100">CNN Feature Visualizer</h3>
            <p className="text-xs text-slate-400">Real-time Computer Vision (CV) operations inside network layer feed-forward loops</p>
          </div>
        </div>
        <span className="text-xs font-mono bg-cyan-500/10 text-cyan-400 border border-cyan-500/25 px-2.5 py-1 rounded-full flex items-center gap-1.5">
          <Zap className="w-3.5 h-3.5" /> CNN MODE
        </span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Navigation Sidebar */}
        <div className="lg:col-span-5 flex flex-col gap-3">
          {steps.map((step) => {
            const isActive = step.id === activeStep;
            return (
              <button
                key={step.id}
                onClick={() => setActiveStep(step.id)}
                className={`w-full text-left p-3.5 rounded-xl transition duration-250 border flex flex-col gap-1.5 ${
                  isActive
                    ? 'bg-slate-800/80 border-cyan-500 text-slate-50 shadow-md'
                    : 'bg-slate-950/40 border-slate-800/60 text-slate-400 hover:bg-slate-850/60 hover:text-slate-250'
                }`}
              >
                <div className="flex items-center justify-between w-full">
                  <span className="text-sm font-semibold tracking-tight">{step.title}</span>
                  <span className={`text-[10px] uppercase font-mono px-2 py-0.5 rounded-full ${
                    isActive ? 'bg-cyan-500/25 text-cyan-300' : 'bg-slate-800 text-slate-400'
                  }`}>
                    {step.badge}
                  </span>
                </div>
                <p className="text-xs leading-relaxed opacity-90">{step.description}</p>
              </button>
            );
          })}

          {activeStep === 0 && (
            <div className="bg-slate-950/60 border border-slate-800/50 p-4 rounded-xl mt-1 flex flex-col gap-3">
              <span className="text-xs font-semibold text-slate-400 flex items-center gap-1.5">
                <Sliders className="w-3.5 h-3.5 text-cyan-400" /> Preprocessing Parameters (Keras Rescale)
              </span>
              <div>
                <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
                  <span>Rescaling Contrast Factor</span>
                  <span className="font-mono text-cyan-400">{contrast}%</span>
                </div>
                <input
                  type="range"
                  min="-50"
                  max="100"
                  value={contrast}
                  onChange={(e) => setContrast(Number(e.target.value))}
                  className="w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
                />
              </div>
              <div>
                <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
                  <span>Channel Intensity Offset</span>
                  <span className="font-mono text-cyan-400">{brightness}%</span>
                </div>
                <input
                  type="range"
                  min="50"
                  max="150"
                  value={brightness}
                  onChange={(e) => setBrightness(Number(e.target.value))}
                  className="w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
                />
              </div>
            </div>
          )}
        </div>

        {/* Live Canvas Feed */}
        <div className="lg:col-span-7 flex flex-col items-center justify-center bg-slate-950 rounded-2xl border border-slate-850 p-6 relative overflow-hidden">
          <div className="mb-4 text-center">
            <span className="text-xs uppercase font-mono text-slate-400 tracking-wide">
              Tensor Extraction Viewport
            </span>
          </div>

          <div className="relative w-[224px] h-[224px] border-2 border-slate-800 rounded-xl overflow-hidden bg-slate-900 flex items-center justify-center group shadow-inner">
            <canvas
              ref={canvasRef}
              className={`w-[224px] h-[224px] block transition-transform duration-300 ${
                isProcessing ? 'opacity-40 scale-95' : 'opacity-100 scale-100'
              }`}
            />
            {isProcessing && (
              <div className="absolute inset-0 flex items-center justify-center bg-black/30 backdrop-blur-xs">
                <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-cyan-400"></div>
              </div>
            )}
            
            {/* Corner boundary guides referencing architectural coordinates */}
            <div className="absolute top-2 left-2 w-4 h-4 border-t-2 border-l-2 border-cyan-400/50 pointer-events-none"></div>
            <div className="absolute top-2 right-2 w-4 h-4 border-t-2 border-r-2 border-cyan-400/50 pointer-events-none"></div>
            <div className="absolute bottom-2 left-2 w-4 h-4 border-b-2 border-l-2 border-cyan-400/50 pointer-events-none"></div>
            <div className="absolute bottom-2 right-2 w-4 h-4 border-b-2 border-r-2 border-cyan-400/50 pointer-events-none"></div>
          </div>

          <div className="mt-4 flex items-center gap-2 text-xs text-emerald-400 font-mono bg-emerald-500/10 px-3 py-1.5 rounded-lg border border-emerald-500/20">
            <CheckCircle2 className="w-3.5 h-3.5" /> Preprocessed tensor fully mapped to weights catalog
          </div>
        </div>
      </div>
    </div>
  );
}
