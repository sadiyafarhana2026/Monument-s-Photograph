import React, { useState } from 'react';
import { Landmark, Mail, Phone, MapPin, Send, CheckCircle2, ShieldAlert, Cpu, Heart, Code2, Layers, Image as ImageIcon } from 'lucide-react';

// Hero Section Component
interface HeroSectionProps {
  onStartClick: () => void;
  onExploreClick: () => void;
}

export function HeroSection({ onStartClick, onExploreClick }: HeroSectionProps) {
  return (
    <div className="bg-slate-900 text-white rounded-3xl p-6 md:p-12 relative overflow-hidden mb-8 border border-slate-800 shadow-xl">
      <div className="absolute top-0 right-0 w-80 h-80 bg-indigo-500/10 rounded-full blur-3xl -mr-16 -mt-16"></div>
      <div className="absolute bottom-0 left-1/4 w-60 h-60 bg-violet-500/10 rounded-full blur-3xl"></div>

      <div className="relative max-w-3xl flex flex-col items-start gap-4">
        <span className="text-xs uppercase font-mono tracking-widest text-indigo-400 font-bold bg-indigo-500/15 border border-indigo-500/25 px-2.5 py-1 rounded-full flex items-center gap-1.5">
          <Layers className="w-3.5 h-3.5 animate-pulse" /> CNN & Transfer Learning Vision Matrix
        </span>
        
        <h1 className="font-sans font-extrabold text-3xl md:text-5xl text-slate-100 tracking-tight leading-none">
          Identify Global Monuments <br />
          <span className="bg-gradient-to-r from-indigo-400 to-violet-400 bg-clip-text text-transparent">with Vision AI Layers</span>
        </h1>
        
        <p className="text-sm md:text-base text-slate-300 leading-relaxed mt-2 max-w-2xl">
          Instantly recognize historical architectural boundaries from uploaded photographs. Experience real-time CNN convolution layer visualizers, explore extensive travel facts, and read histories aloud.
        </p>

        <div className="flex flex-wrap gap-3 mt-4">
          <button
            onClick={onStartClick}
            className="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs md:text-sm px-6 py-3 rounded-xl transition duration-200 flex items-center gap-1.5 shadow-lg shadow-indigo-600/15"
          >
            Launch Photo Analyzer
          </button>
          
          <button
            onClick={onExploreClick}
            className="bg-slate-800 hover:bg-slate-750 text-slate-300 border border-slate-700 font-semibold text-xs md:text-sm px-6 py-3 rounded-xl transition duration-200"
          >
            Explore Scans Register
          </button>
        </div>
      </div>
    </div>
  );
}

// About/Theoretical Model Page
export function AboutPage() {
  const architectures = [
    {
      title: 'Rescaling / Normalize',
      desc: 'The input layer enforces standard size matrix boundaries of 224x224 pixels and rescales channel pixel intensities from uint8 [0-255] to floating points [0-1] to support backpropagation weights lookup.'
    },
    {
      title: 'Convolutional Kernels',
      desc: 'Filters (kernels) move across RGB values to compute weight dot-products. This identifies low-level edges, textures, and lines which later synthesize into complex columns and domes.'
    },
    {
      title: 'Local Pooling Layers',
      desc: 'Reduces spatial dimensions while keeping highest activation weights. Downsampling decreases computing constraints while building structural spatial invariance.'
    },
    {
      title: 'Softmax Densities',
      desc: 'Outputs a probability distribution array across our monument classes (Taj Mahal, Qutub Minar, Eiffel Tower, etc.) with values designating overall model matching confidence.'
    }
  ];

  return (
    <div className="space-y-8 bg-white rounded-3xl border border-slate-100 shadow-xl p-6 md:p-8">
      <div>
        <h2 className="font-sans font-extrabold text-slate-900 text-2xl tracking-tight">Theoretical Vision Model & Architecture</h2>
        <p className="text-slate-500 text-sm mt-1">Under the hood of convolutional neural network (CNN) architectures and landmark identification</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div>
          <h3 className="text-slate-800 font-bold font-sans text-base mb-3 flex items-center gap-2">
            <Cpu className="text-indigo-600 w-5 h-5" /> CNN Feedforward Mechanics
          </h3>
          <p className="text-sm text-slate-600 leading-relaxed mb-4">
            Monument Vision AI utilizes a specialized deep Convolutional Neural Network (CNN) incorporating transfer learning from high-parameter pre-trained vision transformer backbones. Computer Vision processes raw pixel matrices to construct mathematical descriptors of arches, minarets, spires, and columns.
          </p>
          <p className="text-sm text-slate-600 leading-relaxed">
            By running high-frequency edge filters (like the Sobel operators demonstrated in our real-time visualizer), the neural layers decouple lighting conditions from absolute structural ratios, ensuring accurate predictions regardless of weather or photo angle constraints.
          </p>
        </div>

        <div className="bg-slate-900 text-white rounded-2xl p-5 border border-slate-800 shadow-inner">
          <h4 className="text-indigo-400 font-mono text-xs uppercase font-bold tracking-wider mb-3">Model Catalog Classes</h4>
          <div className="grid grid-cols-2 gap-2 text-xs font-semibold text-slate-350">
            <div className="flex items-center gap-1.5 p-2 bg-slate-950/40 rounded-lg">🏛️ Taj Mahal</div>
            <div className="flex items-center gap-1.5 p-2 bg-slate-950/40 rounded-lg">🗼 Qutub Minar</div>
            <div className="flex items-center gap-1.5 p-2 bg-slate-950/40 rounded-lg">🧱 India Gate</div>
            <div className="flex items-center gap-1.5 p-2 bg-slate-950/40 rounded-lg">🗼 Eiffel Tower</div>
            <div className="flex items-center gap-1.5 p-2 bg-slate-950/40 rounded-lg">🗽 Statue of Liberty</div>
            <div className="flex items-center gap-1.5 p-2 bg-slate-950/40 rounded-lg">🏰 Red Fort</div>
            <div className="flex items-center gap-1.5 p-2 bg-slate-950/40 rounded-lg">🕌 Charminar</div>
            <div className="flex items-center gap-1.5 p-2 bg-slate-950/40 rounded-lg">🛕 Mysore Palace</div>
          </div>
          <div className="mt-4 border-t border-slate-800 pt-3 flex items-center justify-between text-[11px] text-slate-500 font-mono">
            <span>Layers count: 19 convolutional</span>
            <span>Dataset size: 2.3K photos</span>
          </div>
        </div>
      </div>

      <div className="border-t border-slate-100 my-4"></div>

      <div>
        <h3 className="text-slate-800 font-bold font-sans text-base mb-4">Core Model Layer Specifications</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {architectures.map((arch, index) => (
            <div key={index} className="bg-slate-50 border border-slate-150 p-4 rounded-xl">
              <span className="w-6 h-6 rounded-md bg-indigo-50 border border-indigo-100 text-indigo-600 font-bold text-xs flex items-center justify-center mb-3">
                {index + 1}
              </span>
              <h4 className="font-sans font-bold text-slate-800 text-sm">{arch.title}</h4>
              <p className="text-slate-500 text-xs mt-1.5 leading-relaxed">{arch.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// Contact Page Component
export function ContactPage() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [subject, setSubject] = useState('');
  const [msg, setMsg] = useState('');
  const [success, setSuccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email || !msg) return;
    setSuccess(true);
    // Clear inputs
    setName('');
    setEmail('');
    setSubject('');
    setMsg('');
    setTimeout(() => setSuccess(false), 5000);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 bg-white rounded-3xl border border-slate-100 shadow-xl p-6 md:p-8">
      {/* Contact info desk */}
      <div className="lg:col-span-5 flex flex-col justify-between gap-6 dark:bg-slate-950 p-5 rounded-2xl border border-slate-50 bg-slate-50/50">
        <div>
          <span className="text-[10px] uppercase font-mono tracking-widest text-indigo-600 bg-indigo-50 border border-indigo-100 px-2.5 py-1 rounded-md font-semibold">
            Support Desk
          </span>
          <h2 className="font-sans font-extrabold text-slate-900 text-2xl tracking-tight mt-3">
            Contact Monument <br />Vision AI Team
          </h2>
          <p className="text-sm text-slate-500 mt-2 leading-relaxed">
            Have questions regarding deep learning training methodologies, expanding classifications models or catalog lists? Get in touch with our help center desk.
          </p>
        </div>

        <div className="space-y-4 text-sm text-slate-600">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-indigo-50 text-indigo-600 rounded-lg">
              <Mail className="w-4 h-4" />
            </div>
            <span>support@monumentvision.ai</span>
          </div>
          
          <div className="flex items-center gap-3">
            <div className="p-2 bg-indigo-50 text-indigo-600 rounded-lg">
              <Phone className="w-4 h-4" />
            </div>
            <span>+1 (800) 555-VISION</span>
          </div>

          <div className="flex items-center gap-3">
            <div className="p-2 bg-indigo-50 text-indigo-600 rounded-lg">
              <MapPin className="w-4 h-4" />
            </div>
            <span>Google Scholar Neural Workspace, Lab-7</span>
          </div>
        </div>

        <div className="border-t border-slate-200/50 pt-4 text-xs text-slate-400">
          We usually reply back within 24 standard business hours.
        </div>
      </div>

      {/* Form card */}
      <div className="lg:col-span-7">
        <form onSubmit={handleSubmit} className="space-y-4">
          <h3 className="font-sans font-bold text-slate-800 text-lg">Send Inquiry Ticket</h3>
          
          {success && (
            <div className="bg-emerald-50 border border-emerald-150 p-3.5 rounded-xl text-emerald-700 text-xs flex items-center gap-2">
              <CheckCircle2 className="w-4.5 h-4.5 text-emerald-650 shrink-0" />
              <span>Inquiry ticket successfully saved in database. Support team will email back shortly.</span>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">Your Name *</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="FullName"
                className="w-full bg-slate-50 border border-slate-200 py-2 px-3 rounded-xl text-sm focus:ring-1 focus:ring-indigo-500 focus:outline-none focus:bg-white transition"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">Email address *</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@domain.com"
                className="w-full bg-slate-50 border border-slate-200 py-2 px-3 rounded-xl text-sm focus:ring-1 focus:ring-indigo-500 focus:outline-none focus:bg-white transition"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">Subject Topic</label>
            <input
              type="text"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              placeholder="e.g. Request to include custom monument classes"
              className="w-full bg-slate-50 border border-slate-200 py-2 px-3 rounded-xl text-sm focus:ring-1 focus:ring-indigo-500 focus:outline-none focus:bg-white transition"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">Inquiry Description *</label>
            <textarea
              value={msg}
              onChange={(e) => setMsg(e.target.value)}
              rows={4}
              placeholder="Write your details..."
              className="w-full bg-slate-50 border border-slate-200 py-2 px-3 rounded-xl text-sm focus:ring-1 focus:ring-indigo-500 focus:outline-none focus:bg-white transition"
              required
            />
          </div>

          <div>
            <button
              type="submit"
              className="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs px-5 py-2.5 rounded-xl transition duration-200 flex items-center gap-1.5 shadow"
            >
              <Send className="w-3.5 h-3.5" /> Submit Message Case
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

// Footer Component
export function Footer() {
  return (
    <footer className="bg-slate-900 text-white border-t border-slate-800 py-8 mt-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-center gap-4 text-center md:text-left">
          <div className="flex items-center gap-2">
            <div className="bg-indigo-600 p-1.5 rounded-lg">
              <Landmark className="w-4 h-4 text-white" />
            </div>
            <span className="font-sans font-extrabold tracking-tight text-sm">
              Monument Vision <span className="font-mono text-xs font-semibold bg-indigo-500/20 text-indigo-400 px-1.5 py-0.5 rounded-full">AI</span>
            </span>
          </div>

          <p className="text-xs text-slate-500 flex items-center gap-1 justify-center">
            Crafted with <Heart className="w-3 h-3 text-red-500 fill-red-500" /> for AI Studio. Powered by TensorFlow CNN model and Google Gemini 3.5.
          </p>

          <div className="flex gap-4 text-xs font-mono text-slate-500">
            <span>LICENSE: Apache-2.0</span>
            <span>VERSION: 5.2.0</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
