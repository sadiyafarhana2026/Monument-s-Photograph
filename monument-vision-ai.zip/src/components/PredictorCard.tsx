import React, { useState, useRef } from 'react';
import { Upload, Image as ImageIcon, Sparkles, HelpCircle, AlertCircle, RefreshCw, Cpu } from 'lucide-react';
import { MonumentScan } from '../types.js';

interface PredictorCardProps {
  onPredictionComplete: (scan: MonumentScan) => void;
  userId?: string;
}

export default function PredictorCard({ onPredictionComplete, userId }: PredictorCardProps) {
  const [dragActive, setDragActive] = useState<boolean>(false);
  const [imageSrc, setImageSrc] = useState<string | null>(null);
  const [fileName, setFileName] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  const [loadingStep, setLoadingStep] = useState<string>('');
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const loadingPhrases = [
    'Rescaling tensor to raw 224x224 bounding matrix...',
    'Performing floating-point channel normalize [0.0 - 1.0]...',
    'Passing input values through primary 3x3 Conv2D layers...',
    'Convolving kernel arrays & pooling local feature maps...',
    'Inquiring semantic classification logits from host encoder...',
    'Rendering Grad-CAM activations & building travel catalog...'
  ];

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processFile(e.target.files[0]);
    }
  };

  const processFile = (file: File) => {
    if (!file.type.startsWith('image/')) {
      setError('Please provide a valid image file (PNG, JPG, WEBP).');
      return;
    }
    
    setError(null);
    setFileName(file.name);

    const reader = new FileReader();
    reader.onload = (e) => {
      if (e.target?.result) {
        setImageSrc(e.target.result as string);
      }
    };
    reader.readAsDataURL(file);
  };

  const onButtonClick = () => {
    fileInputRef.current?.click();
  };

  const clearImage = () => {
    setImageSrc(null);
    setFileName('');
    setError(null);
  };

  const triggerAnalyze = async () => {
    if (!imageSrc) return;

    setLoading(true);
    setError(null);

    // Staggered loading status text updater mimicking live CNN weights pass
    let currentStepIdx = 0;
    setLoadingStep(loadingPhrases[0]);
    const stepInterval = setInterval(() => {
      currentStepIdx = (currentStepIdx + 1) % loadingPhrases.length;
      setLoadingStep(loadingPhrases[currentStepIdx]);
    }, 1800);

    try {
      const response = await fetch('/api/predict', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          imageBase64: imageSrc,
          userId: userId || 'user-1',
          mimeType: imageSrc.split(';')[0].split(':')[1] || 'image/png'
        })
      });

      const data = await response.json();
      clearInterval(stepInterval);

      if (!response.ok) {
        throw new Error(data.error || data.message || 'Server encountered an issue predicting monument details.');
      }

      onPredictionComplete(data);
    } catch (err: any) {
      clearInterval(stepInterval);
      setError(err.message || 'An unexpected networking failure occurred. Please verify your GEMINI_API_KEY is configured.');
      setLoading(false);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-3xl shadow-xl border border-slate-100 p-6 flex flex-col md:flex-row gap-8 relative overflow-hidden">
      
      {/* Upload/Preview Drag area */}
      <div className="flex-1 flex flex-col justify-between">
        <div>
          <h3 className="font-sans font-extrabold text-2xl text-slate-900 tracking-tight flex items-center gap-2">
            <Sparkles className="text-amber-500 w-6 h-6" /> Identify Landmark
          </h3>
          <p className="text-sm text-slate-500 mt-1 mb-5">
            Drop or browse a clear photo of any global monument. High-weight vision layers will predict, classify, and generate descriptions immediately.
          </p>
        </div>

        {!imageSrc ? (
          <div
            onDragEnter={handleDrag}
            onDragOver={handleDrag}
            onDragLeave={handleDrag}
            onDrop={handleDrop}
            className={`flex-1 min-h-[220px] flex flex-col items-center justify-center border-2 border-dashed rounded-2xl p-6 transition duration-300 ${
              dragActive
                ? 'border-indigo-600 bg-indigo-50/50'
                : 'border-slate-250 hover:border-indigo-450 hover:bg-slate-50/30'
            }`}
          >
            <div className="bg-indigo-50 p-4 rounded-2xl text-indigo-600 mb-4">
              <Upload className="w-10 h-10" />
            </div>
            
            <button
              onClick={onButtonClick}
              className="text-sm font-semibold text-indigo-600 hover:text-indigo-800 hover:underline"
            >
              Click to upload files
            </button>
            <p className="text-xs text-slate-400 mt-1.5">or drag and drop your image directly here</p>
            <p className="text-[10px] text-slate-400 mt-1 uppercase font-mono">JPG, PNG or WEBP (Max 10MB)</p>
            
            <input
              ref={fileInputRef}
              type="file"
              className="hidden"
              accept="image/*"
              onChange={handleFileChange}
            />
          </div>
        ) : (
          <div className="flex-1 flex flex-col justify-center items-center border border-slate-150 rounded-2xl bg-slate-50 relative p-4 group">
            <img
              src={imageSrc}
              alt="Image viewport preview"
              className="max-h-[260px] max-w-full rounded-lg object-contain shadow-sm"
              referrerPolicy="no-referrer"
            />
            <div className="absolute top-2 right-2 bg-black/60 backdrop-blur-sm text-white text-xs px-2.5 py-1 rounded-full font-mono">
              {fileName.length > 20 ? fileName.slice(0, 17) + '...' : fileName}
            </div>
            
            {!loading && (
              <button
                onClick={clearImage}
                className="absolute bottom-4 left-4 bg-red-600 hover:bg-red-700 text-white text-xs font-semibold px-3.5 py-2 rounded-xl transition duration-200 shadow-lg"
              >
                Remove Picture
              </button>
            )}
          </div>
        )}
      </div>

      {/* Control panel and loader */}
      <div className="w-full md:w-[320px] bg-slate-50/75 rounded-2xl border border-slate-100 p-6 flex flex-col justify-between">
        <div>
          <span className="text-xs uppercase font-mono tracking-wider text-slate-400 block mb-1">
            Prediction Workflow
          </span>
          <h4 className="font-sans font-bold text-slate-800 text-lg">Classifier controls</h4>
          
          <div className="border-t border-slate-200/60 my-4"></div>

          {loading ? (
            <div className="flex-1 flex flex-col items-center justify-center py-6 text-center">
              <div className="relative mb-4 flex items-center justify-center">
                <div className="w-16 h-16 rounded-full border-4 border-indigo-100 border-t-indigo-500 animate-spin"></div>
                <Cpu className="absolute w-6 h-6 text-indigo-500" />
              </div>
              <h5 className="font-sans font-bold text-slate-900 text-sm">Deep Network Inference Live</h5>
              <div className="bg-indigo-50 border border-indigo-100 text-[11px] text-indigo-600 leading-normal font-mono px-3 py-2 rounded-xl mt-3 min-h-[46px] flex items-center justify-center">
                {loadingStep}
              </div>
            </div>
          ) : (
            <div className="flex flex-col gap-4 text-xs text-slate-500 mt-2">
              <div className="flex items-start gap-2.5">
                <HelpCircle className="w-4 h-4 text-indigo-500 shrink-0 mt-0.5" />
                <span>Supports preloaded datasets like Taj Mahal, Eiffel, Statue of Liberty, Eiffel Tower or other physical landmark coordinates.</span>
              </div>
              <div className="flex items-start gap-2.5">
                <AlertCircle className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                <span>Requires active GEMINI_API_KEY inside AI Studio dev secrets to fetch full historical facts and metadata parameters.</span>
              </div>
            </div>
          )}

          {error && (
            <div className="bg-red-50 border border-red-150 p-3.5 rounded-xl text-red-600 text-xs mt-4 flex items-start gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <div className="flex-1 leading-relaxed">
                <strong className="block font-semibold">Inference Fault:</strong>
                {error}
              </div>
            </div>
          )}
        </div>

        <div className="mt-6">
          {imageSrc && !loading ? (
            <button
              onClick={triggerAnalyze}
              className="w-full bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-700 hover:to-violet-700 text-white font-semibold py-3 px-4 rounded-xl transition duration-250 shadow-md shadow-indigo-600/10 flex items-center justify-center gap-2 focus:ring-2 focus:ring-indigo-500"
            >
              <Cpu className="w-4 h-4" /> Classify Image with AI
            </button>
          ) : (
            <button
              disabled
              className="w-full bg-slate-200 text-slate-400 font-semibold py-3 px-4 rounded-xl cursor-not-allowed flex items-center justify-center gap-2"
            >
              Select Image First
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
