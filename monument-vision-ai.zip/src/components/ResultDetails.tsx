import React, { useState, useEffect } from 'react';
import { Volume2, VolumeX, MapPin, Landmark, Calendar, Award, Star, ListChecks, HelpCircle } from 'lucide-react';
import { MonumentScan } from '../types.js';

interface ResultDetailsProps {
  scan: MonumentScan;
}

export default function ResultDetails({ scan }: ResultDetailsProps) {
  const [activeTab, setActiveTab] = useState<'info' | 'facts' | 'travel'>('info');
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [speechRate, setSpeechRate] = useState<number>(1.0);
  const [utterance, setUtterance] = useState<SpeechSynthesisUtterance | null>(null);

  // Initialize and update speech synthesis object when data changes
  useEffect(() => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      // Cancel any ongoing speaking first
      window.speechSynthesis.cancel();
      setIsPlaying(false);

      // Clean HTML or select read-aloud material
      const textToRead = `${scan.monumentName}. Located in ${scan.location}, ${scan.country}. Completed around the year ${scan.constructionYear}. Design architectural style is ${scan.architectureStyle}. History highlights: ${scan.history}. Key facts: ${scan.famousFacts.join('. ')}`;
      const newUtterance = new SpeechSynthesisUtterance(textToRead);
      newUtterance.rate = speechRate;
      
      newUtterance.onend = () => {
        setIsPlaying(false);
      };
      
      newUtterance.onerror = (e) => {
        console.error('Speech synthesis errored', e);
        setIsPlaying(false);
      };

      setUtterance(newUtterance);
    }

    return () => {
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, [scan, speechRate]);

  const handlePlayPause = () => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
      alert('Text-to-speech features are supported on desktop web browsers. Try opening in a new tab!');
      return;
    }

    if (isPlaying) {
      window.speechSynthesis.pause();
      setIsPlaying(false);
    } else {
      if (window.speechSynthesis.paused) {
        window.speechSynthesis.resume();
        setIsPlaying(true);
      } else if (utterance) {
        window.speechSynthesis.speak(utterance);
        setIsPlaying(true);
      }
    }
  };

  const stopSpeech = () => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      setIsPlaying(false);
    }
  };

  return (
    <div className="bg-white rounded-3xl border border-slate-100 shadow-xl overflow-hidden mt-6">
      
      {/* Banner info header */}
      <div className="bg-slate-900 text-white p-6 relative overflow-hidden">
        
        {/* Abstract design geometry backdrop */}
        <div className="absolute right-0 top-0 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl -mr-20 -mt-20"></div>
        <div className="absolute left-1/3 bottom-0 w-64 h-64 bg-violet-500/10 rounded-full blur-2xl"></div>

        <div className="relative flex flex-col md:flex-row md:items-center md:justify-between gap-6">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="text-[11px] font-mono tracking-widest text-indigo-400 uppercase bg-indigo-500/10 border border-indigo-500/25 px-2.5 py-1 rounded-full">
                AI Inference Matched
              </span>
              <span className="bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs px-2.5 py-1 rounded-full font-mono flex items-center gap-1">
                <Star className="w-3 h-3 fill-emerald-400" /> {scan.confidence}% Match
              </span>
            </div>

            <h2 className="font-serif font-bold text-3xl md:text-5xl text-slate-100 tracking-tight">
              {scan.monumentName}
            </h2>

            <p className="text-sm text-slate-300 mt-2 flex items-center gap-1.5 font-sans">
              <MapPin className="w-4 h-4 text-rose-400 shrink-0" />
              {scan.location}, {scan.country}
            </p>
          </div>

          {/* Text-To-Speech Play Controls */}
          <div className="bg-slate-950/60 border border-slate-800 p-4 rounded-2xl md:w-[280px]">
            <div className="flex items-center justify-between text-xs text-slate-300 mb-2">
              <span className="font-semibold flex items-center gap-1">
                <Volume2 className="w-3.5 h-3.5 text-indigo-400" /> Audio Synthesizer
              </span>
              <span className="font-mono text-[10px] text-slate-400">Speech (TTS)</span>
            </div>
            
            <div className="flex gap-2.5 items-center">
              <button
                onClick={handlePlayPause}
                className={`flex-1 flex items-center justify-center gap-1.5 text-xs text-slate-100 font-semibold py-2 px-3.5 rounded-xl transition duration-200 ${
                  isPlaying 
                    ? 'bg-indigo-600 hover:bg-indigo-700 animate-pulse' 
                    : 'bg-slate-800 hover:bg-slate-700 border border-slate-700'
                }`}
              >
                {isPlaying ? 'Pause Guide' : 'Read Aloud'}
              </button>
              
              {isPlaying && (
                <button
                  onClick={stopSpeech}
                  className="bg-slate-800 hover:bg-slate-755 border border-slate-700 p-2 text-red-400 rounded-xl transition duration-200"
                  title="Stop audio"
                >
                  <VolumeX className="w-4 h-4" />
                </button>
              )}
            </div>

            <div className="mt-2.5 flex items-center justify-between gap-4">
              <span className="text-[10px] text-slate-400">Synthesizer speed:</span>
              <div className="flex gap-1.5">
                {[0.8, 1.0, 1.25].map((rate) => (
                  <button
                    key={rate}
                    onClick={() => setSpeechRate(rate)}
                    className={`text-[9px] font-mono px-2 py-0.5 rounded-md ${
                      speechRate === rate 
                        ? 'bg-indigo-500 text-white font-bold' 
                        : 'bg-slate-900 border border-slate-800 text-slate-400'
                    }`}
                  >
                    {rate}x
                  </button>
                ))}
              </div>
            </div>
          </div>

        </div>
      </div>

      {/* Feature metadata items block */}
      <div className="grid grid-cols-1 md:grid-cols-3 border-b border-slate-100 bg-slate-50/50">
        <div className="p-4 border-r border-b md:border-b-0 border-slate-100 flex items-center gap-3">
          <div className="p-2.5 bg-orange-50 text-orange-500 rounded-xl border border-orange-100">
            <Calendar className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[10px] uppercase font-mono text-slate-400 tracking-wide">Inception Era</span>
            <p className="text-sm font-semibold text-slate-800">{scan.constructionYear}</p>
          </div>
        </div>

        <div className="p-4 border-r border-b md:border-b-0 border-slate-100 flex items-center gap-3">
          <div className="p-2.5 bg-sky-50 text-sky-500 rounded-xl border border-sky-100">
            <Landmark className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[10px] uppercase font-mono text-slate-400 tracking-wide">Architecture Style</span>
            <p className="text-sm font-semibold text-slate-800">{scan.architectureStyle}</p>
          </div>
        </div>

        <div className="p-4 flex items-center gap-3">
          <div className="p-2.5 bg-indigo-50 text-indigo-500 rounded-xl border border-indigo-100">
            <Award className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[10px] uppercase font-mono text-slate-400 tracking-wide">Confidence Log</span>
            <p className="text-sm font-semibold text-slate-800">Coded {scan.confidence}% (VGG-19/A2)</p>
          </div>
        </div>
      </div>

      {/* Dynamic Tab Navigation */}
      <div className="flex border-b border-slate-100 px-6 bg-white overflow-x-auto gap-4">
        {[
          { id: 'info', label: 'History & Background' },
          { id: 'facts', label: 'Famous Facts' },
          { id: 'travel', label: 'Tourist Value' }
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`py-4 px-2.5 border-b-2 text-sm font-semibold whitespace-nowrap transition duration-200 ${
              activeTab === tab.id
                ? 'border-indigo-600 text-indigo-600'
                : 'border-transparent text-slate-400 hover:text-slate-600'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Tab Panels */}
      <div className="p-6 md:p-8">
        
        {activeTab === 'info' && (
          <div className="prose max-w-none text-slate-650 leading-relaxed space-y-4">
            <div className="flex items-center gap-2 mb-4">
              <span className="bg-indigo-50 text-indigo-600 text-xs px-2.5 py-1 rounded-md font-semibold font-mono">Origins</span>
              <span className="text-slate-350 text-xs">Verified by Google AI Studio historical logs</span>
            </div>
            
            {scan.history.split('\n\n').map((paragraph, index) => (
              <p key={index} className="text-base text-slate-600">{paragraph}</p>
            ))}
          </div>
        )}

        {activeTab === 'facts' && (
          <div className="space-y-4">
            <div className="flex items-center gap-2 mb-2">
              <p className="text-xs text-slate-400 font-mono">DISCOVER HIDDEN SECRETS & HISTORIC ANECDOTES</p>
            </div>
            
            {scan.famousFacts && scan.famousFacts.length > 0 ? (
              <div className="grid grid-cols-1 gap-3.5">
                {scan.famousFacts.map((fact, index) => (
                  <div key={index} className="flex gap-4 p-4 rounded-xl bg-slate-50 border border-slate-100">
                    <span className="w-8 h-8 rounded-full bg-indigo-50 border border-indigo-100 text-indigo-600 font-bold flex items-center justify-center text-xs shrink-0 self-start">
                      {index + 1}
                    </span>
                    <p className="text-sm text-slate-600 leading-relaxed font-sans">{fact}</p>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-slate-500 text-sm">No historical facts found in registry catalog.</p>
            )}
          </div>
        )}

        {activeTab === 'travel' && (
          <div className="bg-slate-50 border border-slate-150 rounded-2xl p-5 md:p-6 space-y-5">
            <div className="flex items-center gap-2 mb-1">
              <span className="bg-teal-50 text-teal-700 text-[10px] uppercase tracking-wide px-2.5 py-1 rounded-md font-mono font-bold">
                Tourism Assessment Report
              </span>
            </div>
            
            <p className="text-sm text-slate-600 leading-relaxed font-sans">{scan.touristImportance}</p>
            
            <div className="border-t border-slate-250/60 pt-4 mt-2 grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-white p-4 border border-slate-150 rounded-xl shadow-sm">
                <span className="text-[10px] uppercase font-semibold text-slate-400 tracking-wider flex items-center gap-1.5 mb-1">
                  <Star className="w-3.5 h-3.5 text-amber-500 shrink-0 fill-amber-400" /> Best Visiting Conditions
                </span>
                <p className="text-xs text-slate-500 font-sans leading-relaxed">For photogrammetry preprocessing and ideal shadows, capture pictures in clear morning light (7:00 AM - 10:00 AM).</p>
              </div>
              <div className="bg-white p-4 border border-slate-150 rounded-xl shadow-sm">
                <span className="text-[10px] uppercase font-semibold text-slate-400 tracking-wider flex items-center gap-1.5 mb-1">
                  <ListChecks className="w-3.5 h-3.5 text-blue-600 shrink-0" /> Global Importance
                </span>
                <p className="text-xs text-slate-500 font-sans leading-relaxed">Ranked as a premier Tier-A historic landmark attraction, generating global attention and architectural influence.</p>
              </div>
            </div>

            {/* Professional Polish - Weekly Tourist Statistics Bar Chart */}
            <div className="border-t border-slate-200/60 pt-5">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-4 font-mono">Visitor Statistics & Activity Intensity</h3>
              <div className="flex items-end gap-3 h-20 max-w-lg">
                <div className="flex-1 bg-blue-100 rounded-t h-[40%] hover:bg-blue-200 transition-colors cursor-pointer" title="Monday: Normal traffic"></div>
                <div className="flex-1 bg-blue-100 rounded-t h-[60%] hover:bg-blue-200 transition-colors cursor-pointer" title="Tuesday: Moderate traffic"></div>
                <div className="flex-1 bg-blue-100 rounded-t h-[90%] hover:bg-blue-200 transition-colors cursor-pointer" title="Wednesday: High traffic"></div>
                <div className="flex-1 bg-blue-600 rounded-t h-[100%] hover:bg-blue-700 transition-colors cursor-pointer" title="Thursday: Peak visiting traffic"></div>
                <div className="flex-1 bg-blue-100 rounded-t h-[70%] hover:bg-blue-200 transition-colors cursor-pointer" title="Friday: Busy hours"></div>
                <div className="flex-1 bg-blue-100 rounded-t h-[30%] hover:bg-blue-200 transition-colors cursor-pointer" title="Saturday: Low queue"></div>
                <div className="flex-1 bg-blue-100 rounded-t h-[45%] hover:bg-blue-200 transition-colors cursor-pointer" title="Sunday: Quiet time"></div>
              </div>
              <div className="flex justify-between text-[10px] text-slate-400 font-bold mt-2 uppercase tracking-tight max-w-lg">
                <span>Mon</span><span>Tue</span><span>Wed</span><span>Thu</span><span>Fri</span><span>Sat</span><span>Sun</span>
              </div>
            </div>
          </div>
        )}
        
      </div>
    </div>
  );
}
