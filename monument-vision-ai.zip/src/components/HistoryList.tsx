import React, { useState } from 'react';
import { Search, Trash2, Calendar, MapPin, Eye, AlertCircle, FileImage } from 'lucide-react';
import { MonumentScan } from '../types.js';

interface HistoryListProps {
  scans: MonumentScan[];
  onSelectScan: (scan: MonumentScan) => void;
  onDeleteScan: (id: string) => void;
}

export default function HistoryList({ scans, onSelectScan, onDeleteScan }: HistoryListProps) {
  const [searchTerm, setSearchTerm] = useState<string>('');

  const filteredScans = scans.filter((scan) => {
    const s = searchTerm.toLowerCase();
    return (
      scan.monumentName.toLowerCase().includes(s) ||
      scan.location.toLowerCase().includes(s) ||
      scan.country.toLowerCase().includes(s) ||
      scan.architectureStyle.toLowerCase().includes(s)
    );
  });

  return (
    <div className="bg-white rounded-3xl border border-slate-100 shadow-xl p-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
        <div>
          <h3 className="font-sans font-extrabold text-slate-900 text-xl tracking-tight flex items-center gap-2">
            <FileImage className="text-indigo-600 w-5.5 h-5.5" /> Predictions Register
          </h3>
          <p className="text-slate-400 text-xs mt-0.5">Explore files classified by deep learning model matching layers</p>
        </div>

        {/* Dynamic Search Input */}
        <div className="relative md:w-72">
          <input
            type="text"
            placeholder="Search scans by name or location..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-50 border border-slate-200 text-slate-800 placeholder-slate-450 pl-9.5 pr-4 py-2 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition duration-200"
          />
          <Search className="absolute left-3 top-2.5 w-4.5 h-4.5 text-slate-400" />
        </div>
      </div>

      <div className="border-t border-slate-100/80 mb-5"></div>

      {filteredScans.length === 0 ? (
        <div className="flex flex-col items-center justify-center text-center py-12 bg-slate-50 rounded-2xl border border-dashed border-slate-200">
          <div className="bg-slate-150 p-3 rounded-full text-slate-400 mb-3">
            <AlertCircle className="w-6 h-6" />
          </div>
          <h4 className="font-sans font-semibold text-slate-700 text-sm">No predictions found</h4>
          <p className="text-slate-400 text-xs px-6 mt-1 leading-normal max-w-sm">
            {searchTerm 
              ? 'None of your cached classification history matches your active search keywords.' 
              : 'You have not analyzed any photographs yet. Go ahead and drop an image in the analyzer!'}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredScans.map((scan) => (
            <div
              key={scan.id}
              className="bg-slate-50 border border-slate-150/70 hover:border-indigo-200 rounded-2xl p-4.5 transition duration-250 hover:bg-indigo-50/10 flex flex-col justify-between group shadow-xs relative"
            >
              <div className="flex gap-4">
                {/* Micro preview thumbnail */}
                <div className="w-16 h-16 rounded-xl bg-slate-100 border border-slate-200 overflow-hidden shrink-0 flex items-center justify-center">
                  <img
                    src={scan.imagePath}
                    alt={scan.monumentName}
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>

                <div className="flex-1 overflow-hidden">
                  <div className="flex items-center justify-between gap-1">
                    <span className="text-[10px] font-mono text-indigo-500 uppercase font-bold bg-indigo-50 border border-indigo-100/60 px-1.5 py-0.5 rounded-sm">
                      {scan.confidence}% Match
                    </span>
                    <span className="text-[10px] font-mono text-slate-400">
                      {new Date(scan.timestamp).toLocaleDateString()}
                    </span>
                  </div>

                  <h4 className="font-sans font-bold text-slate-800 text-sm mt-1 truncate group-hover:text-indigo-600 transition">
                    {scan.monumentName}
                  </h4>

                  <p className="text-[11px] text-slate-500 truncate flex items-center gap-1 mt-0.5">
                    <MapPin className="w-3 h-3 text-red-400 shrink-0" />
                    {scan.location}, {scan.country}
                  </p>
                </div>
              </div>

              <div className="border-t border-slate-200/55 my-3.5"></div>

              <div className="flex items-center justify-between">
                <button
                  onClick={() => onSelectScan(scan)}
                  className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 transition"
                >
                  <Eye className="w-3.5 h-3.5" /> View Analysis Details
                </button>

                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onDeleteScan(scan.id);
                  }}
                  className="text-slate-400 hover:text-red-500 p-1.5 rounded-lg hover:bg-red-50 transition"
                  title="Remove from history log"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
