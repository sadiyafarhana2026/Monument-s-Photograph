import React, { useState, useEffect } from 'react';
import { Users, Library, ShieldCheck, PlusCircle, Trash2, Edit3, Trash, Activity, Search, AlertCircle, Save, X } from 'lucide-react';
import { User, DatasetItem } from '../types.js';

interface AdminPanelProps {
  currentUser: User | null;
}

export default function AdminPanel({ currentUser }: AdminPanelProps) {
  const [activeAdminTab, setActiveAdminTab] = useState<'users' | 'dataset'>('users');
  const [users, setUsers] = useState<User[]>([]);
  const [dataset, setDataset] = useState<DatasetItem[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Editing state for dataset items
  const [editingItem, setEditingItem] = useState<DatasetItem | null>(null);
  const [isAdding, setIsAdding] = useState<boolean>(false);

  // Form states
  const [formName, setFormName] = useState('');
  const [formCountry, setFormCountry] = useState('');
  const [formLocation, setFormLocation] = useState('');
  const [formArch, setFormArch] = useState('');
  const [formYear, setFormYear] = useState('');
  const [formDesc, setFormDesc] = useState('');
  const [formFacts, setFormFacts] = useState('');
  const [formImportance, setFormImportance] = useState('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  useEffect(() => {
    fetchAdminData();
  }, [activeAdminTab]);

  const fetchAdminData = async () => {
    setIsLoading(true);
    try {
      if (activeAdminTab === 'users') {
        const res = await fetch('/api/admin/users');
        const data = await res.json();
        setUsers(data);
      } else {
        const res = await fetch('/api/admin/dataset');
        const data = await res.json();
        setDataset(data);
      }
    } catch (err) {
      console.error('Error fetching admin details', err);
    } finally {
      setIsLoading(false);
    }
  };

  const handlePromoteDemote = async (id: string, currentRole: 'admin' | 'user') => {
    const targetRole = currentRole === 'admin' ? 'user' : 'admin';
    try {
      const res = await fetch(`/api/admin/users/${id}/role`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ role: targetRole })
      });
      if (res.ok) {
        fetchAdminData();
      }
    } catch (e) {
      console.error('Promotion error', e);
    }
  };

  const handleDeleteUser = async (id: string) => {
    if (id === currentUser?.id) {
      alert('You cannot delete your own administration credentials!');
      return;
    }
    if (!confirm('Are you absolutely sure you want to delete this user registration?')) return;
    try {
      const res = await fetch(`/api/admin/users/${id}`, {
        method: 'DELETE'
      });
      if (res.ok) {
        fetchAdminData();
      }
    } catch (e) {
      console.error('Delete error', e);
    }
  };

  const handleDeleteDatasetItem = async (id: string) => {
    if (!confirm('Are you absolutely sure you want to delete this monument reference?')) return;
    try {
      const res = await fetch(`/api/admin/dataset/${id}`, {
        method: 'DELETE'
      });
      if (res.ok) {
        fetchAdminData();
      }
    } catch (e) {
      console.error('Delete database entry error', e);
    }
  };

  const openEditForm = (item: DatasetItem) => {
    setEditingItem(item);
    setIsAdding(false);
    setFormName(item.name);
    setFormCountry(item.country);
    setFormLocation(item.location);
    setFormArch(item.architectureStyle);
    setFormYear(item.constructionYear);
    setFormDesc(item.description);
    setFormFacts(item.facts.join('\n'));
    setFormImportance(item.importance);
    setErrorMsg(null);
  };

  const openAddForm = () => {
    setIsAdding(true);
    setEditingItem(null);
    setFormName('');
    setFormCountry('');
    setFormLocation('');
    setFormArch('');
    setFormYear('');
    setFormDesc('');
    setFormFacts('');
    setFormImportance('');
    setErrorMsg(null);
  };

  const closeForm = () => {
    setIsAdding(false);
    setEditingItem(null);
    setErrorMsg(null);
  };

  const handleSaveItem = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (!formName || !formCountry || !formLocation) {
      setErrorMsg('Monument Name, Country, and Location coordinates are requested parameters.');
      return;
    }

    const payload = {
      name: formName,
      country: formCountry,
      location: formLocation,
      architectureStyle: formArch,
      constructionYear: formYear,
      description: formDesc,
      facts: formFacts.split('\n').filter(line => line.trim().length > 0),
      importance: formImportance
    };

    try {
      let res;
      if (isAdding) {
        res = await fetch('/api/admin/dataset', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
      } else if (editingItem) {
        res = await fetch(`/api/admin/dataset/${editingItem.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
      }

      if (res && res.ok) {
        closeForm();
        fetchAdminData();
      } else {
        const errorData = await res?.json();
        setErrorMsg(errorData.error || 'Server rejected changes. Verify schemas.');
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'Connecting to database server failed.');
    }
  };

  // Pre-filter records
  const filteredUsers = users.filter(u => 
    u.username.toLowerCase().includes(searchQuery.toLowerCase()) || 
    u.fullName.toLowerCase().includes(searchQuery.toLowerCase()) || 
    u.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredDataset = dataset.filter(item => 
    item.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    item.location.toLowerCase().includes(searchQuery.toLowerCase()) || 
    item.country.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="bg-white rounded-3xl border border-slate-100 shadow-xl overflow-hidden">
      
      {/* Admin header */}
      <div className="bg-slate-900 text-white p-6 md:p-8 flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <span className="text-xs uppercase font-mono tracking-widest text-[#a5b4fc] bg-[#a5b4fc]/15 px-2.5 py-1 rounded-full border border-[#a5b4fc]/20 flex items-center gap-1.5 w-fit">
            <ShieldCheck className="w-4 h-4" /> Systems Console
          </span>
          <h2 className="font-sans font-extrabold text-3xl tracking-tight text-slate-100 mt-2">
            Admin Dashboard
          </h2>
          <p className="text-sm text-slate-400 mt-1">
            Configure system classifications, read historical activity databases, and update monuments metadata catalog.
          </p>
        </div>

        {/* Console counters */}
        <div className="flex gap-4">
          <div className="bg-slate-950/60 p-4 border border-slate-800 rounded-2xl flex items-center gap-4">
            <Activity className="text-emerald-400 w-8 h-8" />
            <div>
              <span className="text-[10px] uppercase font-mono text-slate-400 font-semibold tracking-wider">Status Code</span>
              <p className="text-sm text-emerald-400 font-bold font-mono">NODE_ACTIVE</p>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs list navigation */}
      <div className="flex flex-col md:flex-row border-b border-slate-100 bg-slate-50/50 p-4 justify-between items-center gap-4">
        <div className="flex bg-slate-200/60 p-1 rounded-xl">
          <button
            onClick={() => { setActiveAdminTab('users'); setSearchQuery(''); closeForm(); }}
            className={`flex items-center gap-2 px-4 py-2 text-sm font-semibold rounded-lg transition duration-200 ${
              activeAdminTab === 'users'
                ? 'bg-white text-slate-850 shadow-sm'
                : 'text-slate-500 hover:text-slate-700'
            }`}
          >
            <Users className="w-4 h-4" /> Registrants ({users.length})
          </button>
          
          <button
            onClick={() => { setActiveAdminTab('dataset'); setSearchQuery(''); closeForm(); }}
            className={`flex items-center gap-2 px-4 py-2 text-sm font-semibold rounded-lg transition duration-200 ${
              activeAdminTab === 'dataset'
                ? 'bg-white text-slate-850 shadow-sm'
                : 'text-slate-500 hover:text-slate-700'
            }`}
          >
            <Library className="w-4 h-4" /> Monument References ({dataset.length})
          </button>
        </div>

        {/* Context searches */}
        <div className="flex items-center gap-3 w-full md:w-auto">
          <div className="relative flex-1 md:w-64">
            <input
              type="text"
              placeholder={`Search ${activeAdminTab}...`}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-white border border-slate-200 text-slate-800 placeholder-slate-400 pl-9 pr-4 py-1.5 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
            <Search className="absolute left-3 top-2.5 w-3.5 h-3.5 text-slate-400" />
          </div>

          {activeAdminTab === 'dataset' && !isAdding && !editingItem && (
            <button
              onClick={openAddForm}
              className="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs px-3.5 py-1.5 rounded-xl transition duration-200 flex items-center gap-1.5 shrink-0"
            >
              <PlusCircle className="w-4 h-4" /> Add Item
            </button>
          )}
        </div>
      </div>

      {/* Main Admin Section View */}
      <div className="p-6 md:p-8">
        
        {/* Editor forms overlay */}
        {(isAdding || editingItem) && (
          <form onSubmit={handleSaveItem} className="bg-slate-50 border border-slate-250 p-6 rounded-2xl mb-8 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3 mb-3">
              <h3 className="font-sans font-extrabold text-slate-800 text-base">
                {isAdding ? 'Register New Monument Reference' : `Edit Monument Details: ${editingItem?.name}`}
              </h3>
              <button
                type="button"
                onClick={closeForm}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {errorMsg && (
              <div className="bg-red-50 text-red-650 border border-red-150 p-3 rounded-lg text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">Monument Name *</label>
                <input
                  type="text"
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  placeholder="e.g. Statue of Liberty"
                  className="w-full bg-white border border-slate-200 text-slate-800 py-1.5 px-3 rounded-xl text-sm focus:ring-1 focus:ring-indigo-500 focus:outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">Country Location *</label>
                <input
                  type="text"
                  value={formCountry}
                  onChange={(e) => setFormCountry(e.target.value)}
                  placeholder="e.g. United States"
                  className="w-full bg-white border border-slate-200 text-slate-800 py-1.5 px-3 rounded-xl text-sm focus:ring-1 focus:ring-indigo-500 focus:outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">Detailed Address coordinates *</label>
                <input
                  type="text"
                  value={formLocation}
                  onChange={(e) => setFormLocation(e.target.value)}
                  placeholder="e.g. Liberty Island, New York Harbor"
                  className="w-full bg-white border border-slate-200 text-slate-800 py-1.5 px-3 rounded-xl text-sm focus:ring-1 focus:ring-indigo-500 focus:outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">Architecture Style</label>
                <input
                  type="text"
                  value={formArch}
                  onChange={(e) => setFormArch(e.target.value)}
                  placeholder="e.g. Gothic Revival"
                  className="w-full bg-white border border-slate-200 text-slate-800 py-1.5 px-3 rounded-xl text-sm focus:ring-1 focus:ring-indigo-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">Construction Completed Year</label>
                <input
                  type="text"
                  value={formYear}
                  onChange={(e) => setFormYear(e.target.value)}
                  placeholder="e.g. 1886"
                  className="w-full bg-white border border-slate-200 text-slate-800 py-1.5 px-3 rounded-xl text-sm focus:ring-1 focus:ring-indigo-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">Tourist Importance Rating</label>
                <input
                  type="text"
                  value={formImportance}
                  onChange={(e) => setFormImportance(e.target.value)}
                  placeholder="e.g. Highest tourist attraction rating globally."
                  className="w-full bg-white border border-slate-200 text-slate-800 py-1.5 px-3 rounded-xl text-sm focus:ring-1 focus:ring-indigo-500 focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">Historical Description Paragraph</label>
              <textarea
                value={formDesc}
                onChange={(e) => setFormDesc(e.target.value)}
                rows={3}
                placeholder="Write background information..."
                className="w-full bg-white border border-slate-200 text-slate-800 py-1.5 px-3 rounded-xl text-sm focus:ring-1 focus:ring-indigo-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">Famous Facts (One fact per line)</label>
              <textarea
                value={formFacts}
                onChange={(e) => setFormFacts(e.target.value)}
                rows={3}
                placeholder="Inscribed with over 13,000 soldiers names&#10;Features an eternal burner flame..."
                className="w-full bg-white border border-slate-200 text-slate-800 py-1.5 px-3 rounded-xl text-sm font-sans focus:ring-1 focus:ring-indigo-500 focus:outline-none"
              />
            </div>

            <div className="flex gap-2 justify-end">
              <button
                type="button"
                onClick={closeForm}
                className="bg-slate-200 text-slate-700 hover:bg-slate-300 px-4 py-2 rounded-xl text-xs font-semibold"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-1"
              >
                <Save className="w-3.5 h-3.5" /> Save Changes
              </button>
            </div>
          </form>
        )}

        {isLoading ? (
          <div className="flex flex-col items-center justify-center text-center py-12">
            <div className="w-10 h-10 border-2 border-slate-100 border-t-indigo-500 animate-spin rounded-full"></div>
            <p className="text-slate-400 text-xs mt-3.5">Contacting database host registry cache...</p>
          </div>
        ) : activeAdminTab === 'users' ? (
          /* Users registration panel */
          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr className="border-b border-slate-100 bg-slate-50/50 text-left text-[11px] font-mono uppercase tracking-wider text-slate-400">
                  <th className="py-3 px-4 font-bold">Profile Name</th>
                  <th className="py-3 px-4 font-bold">Registration Mail</th>
                  <th className="py-3 px-4 font-bold">Created Timestamp</th>
                  <th className="py-3 px-4 font-bold">Role Classification</th>
                  <th className="py-3 px-4 font-bold text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700 text-sm">
                {filteredUsers.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="py-12 text-center text-slate-400 text-xs">
                      No user registrations match your parameters.
                    </td>
                  </tr>
                ) : (
                  filteredUsers.map((u) => (
                    <tr key={u.id} className="hover:bg-slate-50/40">
                      <td className="py-3.5 px-4 font-semibold text-slate-800">
                        {u.fullName} <span className="font-mono text-[10px] text-slate-400">({u.username})</span>
                      </td>
                      <td className="py-3.5 px-4 text-slate-600">{u.email}</td>
                      <td className="py-3.5 px-4 font-mono text-xs text-slate-400">
                        {new Date(u.createdAt).toLocaleString()}
                      </td>
                      <td className="py-3.5 px-4">
                        <span className={`text-[10px] uppercase font-mono px-2.5 py-0.5 rounded-full ${
                          u.role === 'admin' 
                            ? 'bg-[#a5b4fc]/20 text-indigo-700 border border-[#a5b4fc]/30 font-bold' 
                            : 'bg-slate-100 text-slate-500'
                        }`}>
                          {u.role}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <div className="flex justify-end gap-2.5">
                          <button
                            onClick={() => handlePromoteDemote(u.id, u.role)}
                            className="bg-slate-100 hover:bg-indigo-50 border border-slate-200 hover:border-indigo-200 px-3 py-1 text-[11px] rounded-lg text-slate-700 hover:text-indigo-650 font-semibold transition"
                          >
                            {u.role === 'admin' ? 'Demote to User' : 'Promote Admin'}
                          </button>
                          
                          <button
                            onClick={() => handleDeleteUser(u.id)}
                            className="p-1.5 rounded-lg border border-slate-200 text-slate-400 hover:text-red-500 hover:bg-red-50 hover:border-red-150 transition"
                            title="Remove account registration permanently"
                          >
                            <Trash className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        ) : (
          /* Monument dataset catalogue directory */
          <div className="space-y-4">
            <div className="overflow-x-auto">
              <table className="w-full border-collapse">
                <thead>
                  <tr className="border-b border-slate-100 bg-slate-50/50 text-left text-[11px] font-mono uppercase tracking-wider text-slate-400">
                    <th className="py-3 px-4 font-bold">Monument Name</th>
                    <th className="py-3 px-4 font-bold">Country Location</th>
                    <th className="py-3 px-4 font-bold col-span-2">Architectural Style</th>
                    <th className="py-3 px-4 font-bold">Era</th>
                    <th className="py-3 px-4 font-bold text-right">Management</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-slate-700 text-sm">
                  {filteredDataset.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="py-12 text-center text-slate-400 text-xs">
                        No customized monument references reside inside local storage registry catalog.
                      </td>
                    </tr>
                  ) : (
                    filteredDataset.map((item) => (
                      <tr key={item.id} className="hover:bg-slate-50/40">
                        <td className="py-3.5 px-4 font-bold text-slate-800">{item.name}</td>
                        <td className="py-3.5 px-4 text-slate-500">
                          {item.location}, {item.country}
                        </td>
                        <td className="py-3.5 px-4 italic text-slate-600">{item.architectureStyle}</td>
                        <td className="py-3.5 px-4 font-mono text-xs">{item.constructionYear}</td>
                        <td className="py-3.5 px-4 text-right">
                          <div className="flex justify-end gap-2">
                            <button
                              onClick={() => openEditForm(item)}
                              className="p-1.5 rounded-lg border border-slate-200 text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 hover:border-indigo-200 transition"
                              title="Edit item references"
                            >
                              <Edit3 className="w-3.5 h-3.5" />
                            </button>
                            
                            <button
                              onClick={() => handleDeleteDatasetItem(item.id)}
                              className="p-1.5 rounded-lg border border-slate-200 text-slate-400 hover:text-red-500 hover:bg-red-50 hover:border-red-150 transition"
                              title="Remove monument permanent reference record"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
