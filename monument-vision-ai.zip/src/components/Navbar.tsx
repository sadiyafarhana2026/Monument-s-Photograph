import React, { useState } from 'react';
import { Landmark, User as UserIcon, ShieldAlert, LogOut, Moon, Sun, Shield, LogIn, Edit2, KeyRound } from 'lucide-react';
import { User } from '../types.js';

interface NavbarProps {
  currentUser: User | null;
  onLogout: () => void;
  onLoginClick: () => void;
  onNavigate: (view: string) => void;
  activeView: string;
  onProfileUpdate: (p: { fullName: string; email: string }) => void;
}

export default function Navbar({
  currentUser,
  onLogout,
  onLoginClick,
  onNavigate,
  activeView,
  onProfileUpdate
}: NavbarProps) {
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [profileName, setProfileName] = useState(currentUser?.fullName || '');
  const [profileEmail, setProfileEmail] = useState(currentUser?.email || '');
  const [isUpdating, setIsUpdating] = useState(false);

  const triggerProfileModal = () => {
    if (currentUser) {
      setProfileName(currentUser.fullName);
      setProfileEmail(currentUser.email);
    }
    setShowProfileModal(!showProfileModal);
  };

  const handleUpdateProfileSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    setIsUpdating(true);

    try {
      const res = await fetch('/api/auth/profile', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: currentUser.id,
          fullName: profileName,
          email: profileEmail
        })
      });

      if (res.ok) {
        onProfileUpdate({ fullName: profileName, email: profileEmail });
        setShowProfileModal(false);
      }
    } catch (err) {
      console.error('Failed to update profile settings', err);
    } finally {
      setIsUpdating(false);
    }
  };

  return (
    <nav className="bg-slate-900 border-b border-slate-800 text-white sticky top-0 z-50 shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Logo Brand banner */}
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => onNavigate('predict')}>
            <div className="bg-blue-600 p-2 rounded-xl text-white shadow-sm shadow-blue-500/10">
              <Landmark className="w-5 h-5" />
            </div>
            <span className="font-sans font-extrabold text-lg tracking-tight text-slate-100 flex items-center gap-1.5">
              Monument Vision <span className="font-mono text-xs font-semibold bg-blue-500/20 text-blue-400 px-2 py-0.5 rounded-full border border-blue-500/20">AI</span>
            </span>
          </div>

          {/* Navigation Links list */}
          <div className="hidden md:flex items-center space-x-1.5">
            {[
              { id: 'predict', label: 'Inference Hub' },
              { id: 'history', label: 'Classification Register' },
              { id: 'about', label: 'Theoretical Model' },
              { id: 'contact', label: 'Support & Desk' }
            ].map((link) => (
              <button
                key={link.id}
                onClick={() => onNavigate(link.id)}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold transition duration-220 ${
                  activeView === link.id
                    ? 'bg-slate-800 text-blue-400 font-extrabold border border-slate-700'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
                }`}
              >
                {link.label}
              </button>
            ))}

            {currentUser?.role === 'admin' && (
              <button
                onClick={() => onNavigate('admin')}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold transition duration-220 flex items-center gap-1.5 ${
                  activeView === 'admin'
                    ? 'bg-slate-800 text-blue-400 border border-slate-700'
                    : 'text-rose-400 hover:text-rose-300 hover:bg-rose-500/5'
                }`}
              >
                <Shield className="w-3.5 h-3.5" /> Admin Console
              </button>
            )}
          </div>

          {/* User Auth controls */}
          <div className="flex items-center gap-3">
            {currentUser ? (
              <div className="flex items-center gap-2">
                <button
                  onClick={triggerProfileModal}
                  className="bg-slate-800 hover:bg-slate-750 text-slate-200 hover:text-blue-400 p-2 rounded-xl border border-slate-700/60 flex items-center gap-1.5 text-xs font-bold transition"
                  title="Edit client profile settings"
                >
                  <UserIcon className="w-4 h-4 text-blue-400" />
                  <span className="hidden sm:inline max-w-[110px] truncate">{currentUser.fullName}</span>
                </button>
                
                <button
                  onClick={onLogout}
                  className="bg-slate-950/40 hover:bg-red-500/10 text-slate-400 hover:text-red-400 p-2 rounded-xl border border-slate-800 hover:border-red-500/20 transition"
                  title="Exit session"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <button
                onClick={onLoginClick}
                className="bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs px-4 py-2 rounded-xl flex items-center gap-1.5 transition shadow-sm shadow-blue-500/20"
              >
                <LogIn className="w-4 h-4" /> Guest Login
              </button>
            )}
          </div>

        </div>
      </div>

      {/* Dynamic mobile top links bar */}
      <div className="md:hidden flex border-t border-slate-850 px-4 py-2 hover:scroll-smooth overflow-x-auto gap-2 bg-slate-950/40">
        {[
          { id: 'predict', label: 'Predictions' },
          { id: 'history', label: 'History log' },
          { id: 'about', label: 'About Model' },
          { id: 'contact', label: 'Contact Help' }
        ].map((link) => (
          <button
            key={link.id}
            onClick={() => onNavigate(link.id)}
            className={`px-3 py-1.5 rounded-lg text-xs whitespace-nowrap font-semibold ${
              activeView === link.id
                ? 'bg-slate-800 text-indigo-450 border border-slate-700'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {link.label}
          </button>
        ))}

        {currentUser?.role === 'admin' && (
          <button
            onClick={() => onNavigate('admin')}
            className={`px-3 py-1.5 rounded-lg text-xs whitespace-nowrap font-semibold flex items-center gap-1 ${
              activeView === 'admin' ? 'bg-slate-800 text-rose-455' : 'text-rose-400'
            }`}
          >
            <Shield className="w-3.5 h-3.5" /> Admin
          </button>
        )}
      </div>

      {/* User settings modal */}
      {showProfileModal && currentUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl border border-slate-100 p-6 w-full max-w-md shadow-2xl relative text-slate-800">
            <h3 className="font-sans font-extrabold text-slate-900 text-xl tracking-tight mb-2">
              Profile Configurations
            </h3>
            <p className="text-slate-500 text-xs mb-4">Update your client information and registration variables stored inside DB.</p>
            
            <form onSubmit={handleUpdateProfileSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Account mail address</label>
                <input
                  type="email"
                  value={profileEmail}
                  onChange={(e) => setProfileEmail(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 py-2 px-3 rounded-xl text-sm text-slate-800 font-sans focus:ring-1 focus:ring-indigo-500 focus:outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Full Display Name</label>
                <input
                  type="text"
                  value={profileName}
                  onChange={(e) => setProfileName(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 py-2 px-3 rounded-xl text-sm text-slate-800 focus:ring-1 focus:ring-indigo-500 focus:outline-none"
                  required
                />
              </div>

              <div className="bg-indigo-50 border border-indigo-100 p-3.5 rounded-xl text-indigo-755 text-xs flex items-start gap-2 max-w-full">
                <ShieldAlert className="w-4 h-4 shrink-0 text-indigo-500 mt-0.5" />
                <div>
                  <span className="font-semibold block">Access Role: {currentUser.role.toUpperCase()}</span>
                  <span>Registered {new Date(currentUser.createdAt).toLocaleDateString()}. Changes are reflected immediately across prediction logs.</span>
                </div>
              </div>

              <div className="flex gap-2 justify-end pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={triggerProfileModal}
                  className="bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold px-4.5 py-2 rounded-xl transition duration-200"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isUpdating}
                  className="bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold px-4.5 py-2 rounded-xl transition duration-200 flex items-center gap-1"
                >
                  {isUpdating ? 'Saving...' : 'Commit Changes'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </nav>
  );
}
