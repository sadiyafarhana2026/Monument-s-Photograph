export interface User {
  id: string;
  username: string;
  email: string;
  fullName: string;
  role: 'user' | 'admin';
  createdAt: string;
}

export interface MonumentScan {
  id: string;
  userId: string;
  imagePath: string; // base64 or URL
  monumentName: string;
  confidence: number;
  location: string;
  country: string;
  history: string;
  architectureStyle: string;
  famousFacts: string[];
  constructionYear: string;
  touristImportance: string;
  timestamp: string;
}

export interface DatasetItem {
  id: string;
  name: string;
  country: string;
  location: string;
  architectureStyle: string;
  constructionYear: string;
  description: string;
  facts: string[];
  importance: string;
}

export interface AuthState {
  user: User | null;
  token: string | null;
}
