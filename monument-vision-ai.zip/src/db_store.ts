import fs from 'fs';
import path from 'path';
import { User, MonumentScan, DatasetItem } from './types.js';

const DB_FILE = path.join(process.cwd(), 'db.json');

interface DatabaseSchema {
  users: User[];
  scans: MonumentScan[];
  rulesAndDataset: DatasetItem[];
}

const DEFAULT_DATASET: DatasetItem[] = [
  {
    id: '1',
    name: 'Taj Mahal',
    country: 'India',
    location: 'Agra, Uttar Pradesh',
    architectureStyle: 'Mughal Architecture',
    constructionYear: '1648',
    description: 'The Taj Mahal is an ivory-white marble mausoleum on the south bank of the Yamuna river in the Indian city of Agra. It was commissioned in 1632 by the Mughal emperor Shah Jahan to house the tomb of his favourite wife, Mumtaz Mahal.',
    facts: [
      'It was declared a winner of the New 7 Wonders of the World initiative.',
      'Over 20,000 artisans were employed to construct the white marble masterpiece.',
      'The dome of the Taj Mahal is constructed of pure white semi-translucent marble.'
    ],
    importance: 'High. Regarded by many as the finest example of Mughal architecture and a symbol of India\'s rich history, attracting over 6 million tourists annually.'
  },
  {
    id: '2',
    name: 'Qutub Minar',
    country: 'India',
    location: 'New Delhi, Delhi',
    architectureStyle: 'Indo-Islamic Architecture',
    constructionYear: '1199',
    description: 'Qutub Minar is a minaret and "victory tower" that forms part of the Qutb complex, a UNESCO World Heritage Site in the Mehrauli area of New Delhi, India. Constructed from red sandstone and marble, it stands 72.5 meters tall.',
    facts: [
      'It is the tallest brick minaret in the world.',
      'The tower contains 379 spiral steps leading to the top.',
      'An iron pillar inside the complex has remained entirely rust-free for over 1600 years.'
    ],
    importance: 'A towering symbol of Delhi\'s Sultanate period and a stellar example of complex Islamic engineering integrated with local stoneworking traditions.'
  },
  {
    id: '3',
    name: 'India Gate',
    country: 'India',
    location: 'New Delhi, Delhi',
    architectureStyle: 'Triumphal Arch',
    constructionYear: '1931',
    description: 'The India Gate is a war memorial located astride the Rajpath, on the eastern edge of the ceremonial axis of New Delhi, formerly called Duty Path. It stands as a memorial to 70,000 soldiers of the British Indian Army who died in the First World War.',
    facts: [
      'Designed by the legendary architect Sir Edwin Lutyens.',
      'The names of over 13,000 soldiers are inscribed on the walls of the gate.',
      'Houses the Amar Jawan Jyoti, an eternal flame honoring unknown fallen soldiers.'
    ],
    importance: 'A national shrine symbolizing ultimate bravery and dedication, acting as a prominent landmark and gathering place for citizens and visitors in New Delhi.'
  },
  {
    id: '4',
    name: 'Eiffel Tower',
    country: 'France',
    location: 'Paris, Île-de-France',
    architectureStyle: 'Wrought-Iron Lattice',
    constructionYear: '1889',
    description: 'The Eiffel Tower is a wrought-iron lattice tower on the Champ de Mars in Paris, France. Named after the engineer Gustave Eiffel, whose company designed and built the tower as the centerpiece of the 1889 World\'s Fair.',
    facts: [
      'It was originally built as a temporary structure for the Exposition Universelle.',
      'It can grow up to 15 centimeters taller during hot summers due to thermal expansion.',
      'It is repainted by hand every 7 years using 60 tonnes of paint.'
    ],
    importance: 'The global cultural icon of France, one of the most recognizable structures in the world, and the most-visited paid monument globally.'
  },
  {
    id: '5',
    name: 'Statue of Liberty',
    country: 'United States',
    location: 'New York City, New York',
    architectureStyle: 'Neoclassical / Colossal Copper',
    constructionYear: '1886',
    description: 'The Statue of Liberty is a colossal neoclassical sculpture on Liberty Island in New York Harbor within New York City, in the United States. The copper statue, a gift from the people of France to the people of the United States, was designed by French sculptor Frédéric-Auguste Bartholdi.',
    facts: [
      'The statue\'s face was modeled after the sculptor\'s mother, Charlotte.',
      'Its green hue is the result of natural copper oxidation, creating a protective patina.',
      'The seven rays on her crown represent the seven seas and seven continents of the world.'
    ],
    importance: 'A universal symbol of freedom and democracy, greeting millions of immigrants traveling to America\'s shores representing hope and liberty.'
  },
  {
    id: '6',
    name: 'Red Fort',
    country: 'India',
    location: 'Old Delhi, Delhi',
    architectureStyle: 'Indo-Islamic Mughal',
    constructionYear: '1648',
    description: 'The Red Fort is a historic fort in the Old Delhi neighborhood of Delhi, India. It was constructed by Shah Jahan in 1638 when he decided to shift his capital from Agra to Delhi. Famously named for its massive red sandstone retaining walls.',
    facts: [
      'Constructed when Shah Jahan moved his empire\'s capital to Delhi (Shahjahanabad).',
      'The Koh-i-Noor diamond was once part of the royal peacock throne inside this fort.',
      'It is where the Prime Minister of India unfurls the national flag every Independence Day.'
    ],
    importance: 'A core national monument where modern Indian sovereignty is ceremonially proclaimed annually, carrying massive symbolic weight and heritage value.'
  },
  {
    id: '7',
    name: 'Charminar',
    country: 'India',
    location: 'Hyderabad, Telangana',
    architectureStyle: 'Indo-Islamic (Qutb Shahi)',
    constructionYear: '1591',
    description: 'The Charminar is a monument and mosque located in Hyderabad, Telangana, India. Built by Muhammad Quli Qutb Shah in 1591, it became a signature landmark of Hyderabad and an iconic piece of Qutb Shahi architecture.',
    facts: [
      'The name Charminar translates literally to "Four Minarets" in Urdu.',
      'It was constructed to celebrate the end of a devastating plague in Hyderabad.',
      'Its four massive arches frame crucial regional streets and market lanes.'
    ],
    importance: 'The iconic focal point of Hyderabad\'s historical heritage, reflecting centuries of high cultural synthesis and grand architecture.'
  },
  {
    id: '8',
    name: 'Mysore Palace',
    country: 'India',
    location: 'Mysuru, Karnataka',
    architectureStyle: 'Indo-Saracenic Architecture',
    constructionYear: '1912',
    description: 'The Mysore Palace is a historical palace and a royal residence at Mysore in Karnataka, India. It was the official residence of the Wadiyar dynasty and the seat of the Kingdom of Mysore, blending Hindu, Mughal, Rajput, and Gothic styles.',
    facts: [
      'It is illuminated by over 97,000 bulbs on Sundays and public holidays.',
      'The original palace was built from wood and accidentally burned down during a wedding in 1897.',
      'The palace hosts the world-famous ten-day Mysore Dasara festival.'
    ],
    importance: 'One of the grandest royal residences in Asia, widely recognized as India\'s second most visited tourist monument after the Taj Mahal.'
  }
];

export class DbStore {
  private data: DatabaseSchema;

  constructor() {
    this.data = {
      users: [
        {
          id: 'admin-1',
          username: 'admin',
          email: 'admin@monumentvision.ai',
          fullName: 'AI Administrator',
          role: 'admin',
          createdAt: new Date().toISOString()
        },
        {
          id: 'user-1',
          username: 'demo_user',
          email: 'sadiyafarhana2005@gmail.com',
          fullName: 'Sadiya Farhana',
          role: 'user',
          createdAt: new Date().toISOString()
        }
      ],
      scans: [],
      rulesAndDataset: [...DEFAULT_DATASET]
    };
    this.load();
  }

  private load() {
    try {
      if (fs.existsSync(DB_FILE)) {
        const fileContent = fs.readFileSync(DB_FILE, 'utf8');
        const parsed = JSON.parse(fileContent);
        this.data = {
          users: parsed.users || this.data.users,
          scans: parsed.scans || this.data.scans,
          rulesAndDataset: parsed.rulesAndDataset || this.data.rulesAndDataset
        };
      } else {
        this.save();
      }
    } catch (e) {
      console.error('Error loading db file, running with defaults', e);
    }
  }

  private save() {
    try {
      fs.writeFileSync(DB_FILE, JSON.stringify(this.data, null, 2), 'utf8');
    } catch (e) {
      console.error('Failed to write db file', e);
    }
  }

  // Users
  getUsers(): User[] {
    return this.data.users;
  }

  addUser(user: User) {
    this.data.users.push(user);
    this.save();
  }

  updateUser(id: string, updates: Partial<User>) {
    const idx = this.data.users.findIndex(u => u.id === id);
    if (idx !== -1) {
      this.data.users[idx] = { ...this.data.users[idx], ...updates };
      this.save();
      return this.data.users[idx];
    }
    return null;
  }

  deleteUser(id: string) {
    this.data.users = this.data.users.filter(u => u.id !== id);
    this.save();
  }

  // Scans
  getScans(userId?: string): MonumentScan[] {
    if (userId) {
      return this.data.scans.filter(s => s.userId === userId).sort((a,b) => b.timestamp.localeCompare(a.timestamp));
    }
    return this.data.scans.sort((a,b) => b.timestamp.localeCompare(a.timestamp));
  }

  addScan(scan: MonumentScan) {
    this.data.scans.push(scan);
    this.save();
  }

  deleteScan(id: string) {
    this.data.scans = this.data.scans.filter(s => s.id !== id);
    this.save();
  }

  // Dataset
  getDataset(): DatasetItem[] {
    return this.data.rulesAndDataset;
  }

  addDatasetItem(item: DatasetItem) {
    this.data.rulesAndDataset.push(item);
    this.save();
  }

  updateDatasetItem(id: string, updates: Partial<DatasetItem>) {
    const idx = this.data.rulesAndDataset.findIndex(item => item.id === id);
    if (idx !== -1) {
      this.data.rulesAndDataset[idx] = { ...this.data.rulesAndDataset[idx], ...updates };
      this.save();
      return this.data.rulesAndDataset[idx];
    }
    return null;
  }

  deleteDatasetItem(id: string) {
    this.data.rulesAndDataset = this.data.rulesAndDataset.filter(i => i.id !== id);
    this.save();
  }
}

export const dbStore = new DbStore();
