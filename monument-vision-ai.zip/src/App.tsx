/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar.js';
import { HeroSection, AboutPage, ContactPage, Footer } from './components/AboutContact.js';
import PredictorCard from './components/PredictorCard.js';
import CnnVisualizer from './components/CnnVisualizer.js';
import ResultDetails from './components/ResultDetails.js';
import HistoryList from './components/HistoryList.js';
import AdminPanel from './components/AdminPanel.js';
import { User, MonumentScan } from './types.js';
import { Landmark, Sparkles, KeyRound, AlertCircle, FileText, CheckCircle2 } from 'lucide-react';

export default function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [activeView, setActiveView] = useState<string>('predict');
  const [scansHistory, setScansHistory] = useState<MonumentScan[]>([]);
  const [selectedScan, setSelectedScan] = useState<MonumentScan | null>(null);

  // Authentication model dialog states
  const [showAuthModal, setShowAuthModal] = useState<boolean>(false);
  const [isRegisterMode, setIsRegisterMode] = useState<boolean>(false);
  const [authUsername, setAuthUsername] = useState<string>('');
  const [authFullName, setAuthFullName] = useState<string>('');
  const [authEmail, setAuthEmail] = useState<string>('');
  const [authError, setAuthError] = useState<string | null>(null);

  // Auto-login default demo user on mount to provide direct out-of-the-box experience
  useEffect(() => {
    autoLoginDemo();
  }, []);

  const autoLoginDemo = async () => {
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: 'demo_user' })
      });
      if (res.ok) {
        const data = await res.json();
        setCurrentUser(data.user);
        fetchHistory(data.user.id);
      }
    } catch (e) {
      console.error('Demo auto login failed', e);
    }
  };

  const fetchHistory = async (userId: string) => {
    try {
      const res = await fetch(`/api/history?userId=${userId}`);
      if (res.ok) {
        const data = await res.json();
        setScansHistory(data);
      }
    } catch (err) {
      console.error('Failed to retrieve classification history logs', err);
    }
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setScansHistory([]);
    setSelectedScan(null);
    setActiveView('predict');
  };

  const handleAuthSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);

    const url = isRegisterMode ? '/api/auth/register' : '/api/auth/login';
    const payload = isRegisterMode 
      ? { username: authUsername, email: authEmail, fullName: authFullName }
      : { username: authUsername };

    try {
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      const data = await res.json();
      if (res.ok) {
        setCurrentUser(data.user);
        fetchHistory(data.user.id);
        setShowAuthModal(false);
        // Clear forms
        setAuthUsername('');
        setAuthEmail('');
        setAuthFullName('');
      } else {
        setAuthError(data.error || 'Authentication rejected by security weights.');
      }
    } catch (err) {
      setAuthError('Connection to authorization database endpoint timed out.');
    }
  };

  const handlePredictionComplete = (newScan: MonumentScan) => {
    setSelectedScan(newScan);
    // Refresh history
    if (currentUser) {
      fetchHistory(currentUser.id);
    }
  };

  const handleDeleteScan = async (id: string) => {
    try {
      const res = await fetch(`/api/history/${id}`, { method: 'DELETE' });
      if (res.ok) {
        setScansHistory(scansHistory.filter((s) => s.id !== id));
        if (selectedScan?.id === id) {
          setSelectedScan(null);
        }
      }
    } catch (err) {
      console.error('Failed to remove scan log', err);
    }
  };

  const handleProfileUpdate = (profile: { fullName: string; email: string }) => {
    if (currentUser) {
      setCurrentUser({
        ...currentUser,
        fullName: profile.fullName,
        email: profile.email
      });
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col justify-between text-slate-800">
      
      {/* Top Banner alert explaining dev/secrets requirements */}
      <div className="bg-gradient-to-r from-amber-500 to-orange-600 text-white py-2 px-4 text-center text-xs font-semibold flex items-center justify-center gap-2">
        <Sparkles className="w-4.5 h-4.5 shrink-0 animate-bounce" />
        <span>Configure your <strong>GEMINI_API_KEY</strong> inside the <strong>Settings &gt; Secrets</strong> panel to enable real-time architectural description predictions!</span>
      </div>

      <Navbar
        currentUser={currentUser}
        onLogout={handleLogout}
        onLoginClick={() => setShowAuthModal(true)}
        onNavigate={(view) => {
          setActiveView(view);
          // Auto clear selection if moving views
          if (view === 'history') {
            setSelectedScan(null);
          }
        }}
        activeView={activeView}
        onProfileUpdate={handleProfileUpdate}
      />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 flex-1 w-full">
        
        {activeView === 'predict' && (
          <div className="space-y-8">
            <HeroSection
              onStartClick={() => {
                const element = document.getElementById('camera-viewport');
                if (element) element.scrollIntoView({ behavior: 'smooth' });
              }}
              onExploreClick={() => {
                setActiveView('history');
                setSelectedScan(null);
              }}
            />

            <div id="camera-viewport" className="scroll-mt-20">
              <PredictorCard
                onPredictionComplete={handlePredictionComplete}
                userId={currentUser?.id}
              />
            </div>

            {selectedScan && (
              <div className="space-y-8 animate-fade-in">
                {/* Result Cards Display */}
                <ResultDetails scan={selectedScan} />
                
                {/* CNN Visualizer Display */}
                <CnnVisualizer imageSrc={selectedScan.imagePath} />
              </div>
            )}
          </div>
        )}

        {activeView === 'history' && (
          <div className="space-y-8 animate-fade-in">
            {selectedScan ? (
              <div className="space-y-6">
                <button
                  onClick={() => setSelectedScan(null)}
                  className="bg-white hover:bg-slate-50 text-slate-700 font-semibold text-xs border border-slate-200 px-4 py-2 rounded-xl transition flex items-center gap-1.5 shadow"
                >
                  &larr; Back to predictions registry list
                </button>
                <ResultDetails scan={selectedScan} />
                <CnnVisualizer imageSrc={selectedScan.imagePath} />
              </div>
            ) : (
              <HistoryList
                scans={scansHistory}
                onSelectScan={(scan) => setSelectedScan(scan)}
                onDeleteScan={handleDeleteScan}
              />
            )}
          </div>
        )}

        {activeView === 'about' && (
          <div className="animate-fade-in">
            <AboutPage />
          </div>
        )}

        {activeView === 'contact' && (
          <div className="animate-fade-in">
            <ContactPage />
          </div>
        )}

        {activeView === 'admin' && currentUser?.role === 'admin' && (
          <div className="animate-fade-in">
            <AdminPanel currentUser={currentUser} />
          </div>
        )}

      </main>

      <Footer />

      {/* Account Authentication overlay */}
      {showAuthModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl border border-slate-100 p-6 w-full max-w-md shadow-2xl relative text-slate-800">
            <h3 className="font-sans font-extrabold text-slate-900 text-xl tracking-tight mb-1 flex items-center gap-2">
              <KeyRound className="w-5.5 h-5.5 text-indigo-600" />
              {isRegisterMode ? 'Registrar Signup Portal' : 'Classifier Portal'}
            </h3>
            <p className="text-slate-400 text-xs mb-4">
              {isRegisterMode 
                ? 'Create a custom researcher profile to track your classified monuments historically.' 
                : 'Enter your username to access your secure classification database logs.'}
            </p>

            <form onSubmit={handleAuthSubmit} className="space-y-4">
              {authError && (
                <div className="bg-red-50 text-red-650 border border-red-150 p-3 rounded-xl text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{authError}</span>
                </div>
              )}

              {isRegisterMode && (
                <>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-1">Your Display FullName</label>
                    <input
                      type="text"
                      value={authFullName}
                      onChange={(e) => setAuthFullName(e.target.value)}
                      placeholder="e.g. Sadiya Farhana"
                      className="w-full bg-slate-50 border border-slate-200 py-2 px-3 rounded-xl text-sm focus:ring-1 focus:ring-indigo-500 focus:outline-none"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-1">Email address</label>
                    <input
                      type="email"
                      value={authEmail}
                      onChange={(e) => setAuthEmail(e.target.value)}
                      placeholder="e.g. user@domain.com"
                      className="w-full bg-slate-50 border border-slate-200 py-2 px-3 rounded-xl text-sm focus:ring-1 focus:ring-indigo-500 focus:outline-none"
                      required
                    />
                  </div>
                </>
              )}

              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-1">Username Key</label>
                <input
                  type="text"
                  value={authUsername}
                  onChange={(e) => setAuthUsername(e.target.value)}
                  placeholder="e.g. admin or demo_user"
                  className="w-full bg-slate-50 border border-slate-200 py-2 px-3 rounded-xl text-sm focus:ring-1 focus:ring-indigo-500 focus:outline-none focus:bg-white font-mono"
                  required
                />
                {!isRegisterMode && (
                  <p className="text-[10px] text-slate-400 mt-1">To test full Admin Console, type <strong className="font-bold text-indigo-550 font-mono">admin</strong> as username!</p>
                )}
              </div>

              <div className="flex gap-2 justify-between items-center pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsRegisterMode(!isRegisterMode)}
                  className="text-xs text-indigo-650 font-semibold hover:underline"
                >
                  {isRegisterMode ? 'Already registered? Login' : 'New researcher? Signup'}
                </button>

                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => setShowAuthModal(false)}
                    className="bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold px-4 py-2 rounded-xl"
                  >
                    Close
                  </button>
                  <button
                    type="submit"
                    className="bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold px-4 py-2 rounded-xl"
                  >
                    {isRegisterMode ? 'Register Me' : 'Validate'}
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}

