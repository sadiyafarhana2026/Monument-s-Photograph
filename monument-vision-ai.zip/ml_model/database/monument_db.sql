-- Monument Vision AI SQL Schema
-- Target Engines: MySQL or SQLite3

-- 1. Users Registrations Table
CREATE TABLE IF NOT EXISTS users (
    id VARCHAR(50) PRIMARY KEY,
    username VARCHAR(100) UNIQUE NOT NULL,
    email VARCHAR(150) UNIQUE NOT NULL,
    full_name VARCHAR(150) NOT NULL,
    user_role VARCHAR(20) DEFAULT 'user', -- 'user' or 'admin'
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. Scans Classifications History Logs 
CREATE TABLE IF NOT EXISTS monument_scans (
    id VARCHAR(50) PRIMARY KEY,
    user_id VARCHAR(50) NOT NULL,
    image_path LONGTEXT NOT NULL, -- base64 representation or file directory
    monument_name VARCHAR(150) NOT NULL,
    confidence INT DEFAULT 0,
    location VARCHAR(200),
    country VARCHAR(100),
    history TEXT,
    architecture_style VARCHAR(100),
    famous_facts TEXT, -- JSON or comma-separated list
    construction_year VARCHAR(50),
    tourist_importance TEXT,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- 3. Preloaded Dataset Catalog List
CREATE TABLE IF NOT EXISTS monument_dataset (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    country VARCHAR(100) NOT NULL,
    location VARCHAR(200) NOT NULL,
    architecture_style VARCHAR(100),
    construction_year VARCHAR(50),
    description TEXT,
    facts TEXT, -- JSON serialized string
    importance TEXT
);

-- Initial insertion query samples (Default Administrator)
INSERT INTO users (id, username, email, full_name, user_role, created_at)
VALUES ('admin-1', 'admin', 'admin@monumentvision.ai', 'AI Administrator', 'admin', CURRENT_TIMESTAMP)
ON CONFLICT(id) DO NOTHING;
