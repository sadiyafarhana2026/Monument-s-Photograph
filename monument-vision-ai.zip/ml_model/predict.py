"""
Monument Vision AI - Image Classifier Predictor
Feeds preprocessed images into our saved Keras CNN weights file and returns classification outputs.
"""

import sys
import numpy as np
import tensorflow as tf
from preprocessing import load_and_preprocess

# Target dataset classes
CLASSES = [
    'Taj Mahal',
    'Qutub Minar',
    'India Gate',
    'Eiffel Tower',
    'Statue of Liberty',
    'Red Fort',
    'Charminar',
    'Mysore Palace'
]

def predict_monument(image_path, model_path='monument_model.h5'):
    """
    Feeds the processed image matrix into loaded model weights.
    """
    # 1. Preprocess photograph to normalized 224x224 input
    try:
        processed_img = load_and_preprocess(image_path)
    except Exception as e:
        return {"error": f"Image preprocessing failed: {str(e)}"}

    # 2. Expand dimensions to represent standard batch size of 1: (1, 224, 224, 3)
    input_tensor = np.expand_dims(processed_img, axis=0)

    # 3. Load standard Keras weights
    try:
        model = tf.keras.models.load_model(model_path)
    except Exception as e:
        return {"error": f"Loading model weights from {model_path} failed: {str(e)}. Ensure train_model.py was executed."}

    # 4. Invoke Prediction feedforward pass
    predictions = model.predict(input_tensor)[0]
    best_match_idx = np.argmax(predictions)
    confidence = float(predictions[best_match_idx]) * 100

    results = {
        "monumentName": CLASSES[best_match_idx],
        "confidence": round(confidence, 2),
        "scores": {CLASSES[i]: round(float(predictions[i]) * 100, 2) for i in range(len(CLASSES))}
    }

    return results

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python predict.py <path_to_image> [model_weights_path]")
        sys.exit(1)
        
    img_path = sys.argv[1]
    w_path = sys.argv[2] if len(sys.argv) > 2 else 'monument_model.h5'
    
    print(f"Analyzing photograph '{img_path}' using weights in '{w_path}'...")
    res = predict_monument(img_path, w_path)
    print("Prediction outputs:", res)
