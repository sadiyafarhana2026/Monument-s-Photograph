"""
Monument Vision AI - Custom CNN Model Training Flow
Builds, compiles, trains, and saves a Deep Learning classification model for detecting landmarks.
"""

import os
import tensorflow as tf
from tensorflow.keras import layers, models
from tensorflow.keras.preprocessing.image import ImageDataGenerator

# Standard dataset classes requested by the user
CLASSES = [
    'Taj Mahal',
    'Qutub Minar',
    'India Gate',
    'Eiffel Tower',
    'Statue of Liberty',
    'Red Fort',
    'Charminar',
    'Mysore Palace'
]

def build_cnn_model():
    """
    Constructs a robust convolutional neural network (CNN) model for multi-class classification.
    """
    model = models.Sequential([
        # Convolution block 1
        layers.Conv2D(32, (3, 3), activation='relu', input_shape=(224, 224, 3)),
        layers.MaxPooling2D((2, 2)),
        layers.BatchNormalization(),

        # Convolution block 2
        layers.Conv2D(64, (3, 3), activation='relu'),
        layers.MaxPooling2D((2, 2)),
        layers.BatchNormalization(),

        # Convolution block 3
        layers.Conv2D(128, (3, 3), activation='relu'),
        layers.MaxPooling2D((2, 2)),
        layers.BatchNormalization(),

        # Convolution block 4
        layers.Conv2D(256, (3, 3), activation='relu'),
        layers.MaxPooling2D((2, 2)),
        layers.GlobalAveragePooling2D(),

        # Dense Classification Layers
        layers.Dense(512, activation='relu'),
        layers.Dropout(0.4), # Guard against model overfitting
        layers.Dense(len(CLASSES), activation='softmax') # Class probability logits
    ])

    model.compile(
        optimizer='adam',
        loss='categorical_crossentropy',
        metrics=['accuracy']
    )

    return model

def train_network(dataset_dir='./dataset', epochs=15, batch_size=32):
    """
    Leverages Keras ImageDataGenerator directories to train deep learning weights.
    """
    print("Preparing monument augmented training datasets...")
    
    # Check if dataset dir is available
    if not os.path.exists(dataset_dir):
        print(f"Warning: Directory '{dataset_dir}' does not exist yet. Please populate class folders.")
        return

    # Real-time training data augmentation to improve model resilience
    train_datagen = ImageDataGenerator(
        rescale=1./255,
        rotation_range=30,
        width_shift_range=0.2,
        height_shift_range=0.2,
        shear_range=0.2,
        zoom_range=0.2,
        horizontal_flip=True,
        validation_split=0.2 # 20% validation split
    )

    train_generator = train_datagen.flow_from_directory(
        dataset_dir,
        target_size=(224, 224),
        batch_size=batch_size,
        class_mode='categorical',
        subset='training'
    )

    val_generator = train_datagen.flow_from_directory(
        dataset_dir,
        target_size=(224, 224),
        batch_size=batch_size,
        class_mode='categorical',
        subset='validation'
    )

    model = build_cnn_model()
    model.summary()

    print("Beginning monument vision model weights optimization...")
    history = model.fit(
        train_generator,
        epochs=epochs,
        validation_data=val_generator,
        workers=4
    )

    # Save finalized weights model
    model_output_path = './monument_model.h5'
    model.save(model_output_path)
    print(f"CNN Model optimized and saved safely to: {model_output_path}")

    return history

if __name__ == "__main__":
    # Standard dummy run script configuration
    train_network()
