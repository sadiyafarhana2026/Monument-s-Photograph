"""
Monument Vision AI - Preprocessing Module
Using OpenCV to isolate architectural landmarks, resize, and normalize inputs for the CNN model.
"""

import cv2
import numpy as np

def load_and_preprocess(image_path, target_size=(224, 224)):
    """
    Load an image from path, resize, convert color models, and normalize features.
    Matches the frontend CNN Preprocessing visualizer behavior.
    """
    # 1. Load image using OpenCV
    img = cv2.imread(image_path)
    if img is None:
        raise FileNotFoundError(f"Provided photograph not found at {image_path}")

    # 2. Resize to standard target tensor dimensions
    img_resized = cv2.resize(img, target_size, interpolation=cv2.INTER_AREA)

    # 3. Convert color model from BGR (OpenCV default) to RGB representation
    img_rgb = cv2.cvtColor(img_resized, cv2.COLOR_BGR2RGB)

    # 4. Normalize pixel intensity weights from standard uint8 to float32 [0.0 - 1.0]
    img_normalized = img_rgb.astype('float32') / 255.0

    return img_normalized

def extract_sobel_edges(image_path):
    """
    Convolve a Sobel filter over the grayscale matrices to outline architectural boundaries.
    """
    img = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    if img is None:
        raise FileNotFoundError(f"Provided photograph not found at {image_path}")
        
    # Resize for standardization
    img_resized = cv2.resize(img, (224, 224))

    # Apply Sobel operators across X and Y vectors
    sobel_x = cv2.Sobel(img_resized, cv2.CV_64F, 1, 0, ksize=3)
    sobel_y = cv2.Sobel(img_resized, cv2.CV_64F, 0, 1, ksize=3)

    # Calculate gradient magnitudes
    magnitude = np.sqrt(sobel_x**2 + sobel_y**2)
    magnitude = np.uint8(np.minimum(magnitude, 255))

    return magnitude

if __name__ == "__main__":
    print("Monument Vision AI Preprocessing module loaded successfully.")
