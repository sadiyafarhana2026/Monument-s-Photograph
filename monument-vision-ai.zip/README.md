# 🏛️ Monument Vision AI - Monument Description from Photograph

A production-ready full-stack AI-based web application that identifies and describes monuments from uploaded photographs using Computer Vision, Deep Learning, and state-of-the-art vision models. 

Featuring standard user authentication, a live interactive CNN Preprocessing and Activation Heatmap simulator, searchable prediction registrations, fully functional history management logs, real-time Text-to-Speech (TTS) audio synthesizer narration, and a robust administrative data control dashboard.

---

## 🌟 Main Project Features

### 1. User Authentication
* Full signup & login portal for research personnel.
* Secured user session state persistence.
* Dynamic user profile settings stored in the database.

### 2. Monument Photographic Pipeline
* High-contrast graphical drag-and-drop file uploader.
* Immediate high-quality target image preview before prediction triggers.
* Multi-stage loader animations describing tensor operations.

### 3. Real-time CNN Preprocessing Visualizer
* **Normalization Bounding**: Rescales target viewport to standard neural input shapes (224 x 224 pixels).
* **Grayscale Dim Compression**: Illustrates color compression for feature reduction (simulating OpenCV `cvtColor`).
* **Active Sobel Convolution**: Interactive 3x3 filter convolutions mapping boundaries, arches, and ridges.
* **Grad-CAM Attention Heatmap**: Layer overlays showing localized weight hot-spots of deep classifier layers.

### 4. Comprehensive Descriptions
* Accurate country and detailed geo-coordinates location reports.
* Full historical backgrounds and building chronologies.
* Standard architectural design classification (e.g. Mughal, Gothic, Saracenic).
* Deep secrets and interesting famous facts logs.
* Direct tourist importance ratings and perfect visiting conditions alerts.

### 5. Multi-Speaker Audio Synthesis
* Narrates historical landmarks metadata aloud in real time.
* Dedicated Play/Pause voice controls with speed rate adjustments.

### 6. Admin Control Center
* Manage credential access parameters and registrants.
* Add, edit, or delete custom monument classifications, descriptions, and historical details.

---

## 🛠️ Technologies Used

### Frontend Node.js Client
* **HTML5 Canvas & CSS3** (Interactive convolutional shaders)
* **React.js (v19)** with TypeScript typing
* **Vite** (Ultra fast module bundling)
* **Tailwind CSS (v4)** (Responsive UI styling)
* **Lucide Icon Library** (Consistent navigation vectors)

### Backend Service API
* **Express & Node.js** (REST API development)
* **Google Gemini 3.5 Flash** (Vision transformer weights catalog inference)
* **Self-Contained JSON DB Engine** (Mock SQLite/MySQL schema persistence)

### Python Machine Learning System (Included Standalone)
* **TensorFlow / Keras** (Deep CNN neural network model)
* **OpenCV (cv2)** (Image resizing, RGB conversion, Sobel filter kernels)
* **NumPy** (Tensor array mathematical normalization)

---

## 🚀 Installation & Local Launch Steps

### Part 1: Running the Live Node.js Full-Stack App
1. Verify Node.js (v18+) is installed.
2. Clone or download this project's zip contents.
3. In the root project directory, create a `.env` file containing your credentials:
   ```env
   GEMINI_API_KEY="YOUR_GOOGLE_AI_STUDIO_API_KEY"
   ```
4. Run standard launch commands:
   ```bash
   # Install dependency modules
   npm install

   # Boot Live Dev environment
   npm run dev
   ```
5. View the active application at `http://localhost:3000`.

---

## 🧠 Machine Learning Model Training (Python Stack)

Ensure you navigate to the standalone `/ml_model` directory to test custom TensorFlow CNN optimizations offline.

```bash
# 1. Enter the ML workspace directory
cd ml_model

# 2. Install scientific Python libraries
pip install -r requirements.txt

# 3. Organise the images dataset by classes
# Ensure photographs reside in appropriate folder partitions inside: dataset/

# 4. Fire the CNN model trainer backprop code
python train_model.py
# This augmentation compiles layers and writes optimized weights to 'monument_model.h5'

# 5. Run prediction on any photograph file
python predict.py "/path/to/test_image.jpg"
```

---

## 📸 Screenshots Section

#### 1. Real-time Edge Convolution & Grad-CAM Attraction Maps
*A screenshot showing current 224x224 grayscale transformations alongside Sobel derivatives highlighting active architectural borders.*

#### 2. Administrative Dataset Management Console
*A view of the admin spreadsheet modifying facts array strings and description paragraphs directly inside local storage.*

---

## 🔮 Future Enhancements
* **Spatial GPS Grounding**: Sync predictions immediately with real-time phone GPS metadata to trigger Google Maps directions.
* **Camera Streaming Video Feed**: Read monument shapes in live viewport frames utilizing local WebGL canvas encoders.
* **Offline PyTorch Conversion**: Convert final weights file `.h5` model coefficients straight to `.onnx` for mobile offline use.

---

## 👥 Contributors Section
* **Google AI Studio Builder Agent** - Architect and Lead developer.
* **Sadiya Farhana** - Research personnel and Project developer.
