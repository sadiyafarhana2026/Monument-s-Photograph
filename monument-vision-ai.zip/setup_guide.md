# 🏛️ Monument Vision AI - Setup Guide

This guide describes how to install and execute the **Monument Vision AI** full-stack application both locally (with Python & TensorFlow machine learning) and online on hosted servers (with Node.js + Express + Gemini AI Studio engines).

---

## Part A: Running the AI Studio/Node.js Production Stack (Pre-integrated)

This environment runs an Express/Vite full-stack web application. Visual model inference is processed on server-side Gemini 3.5 Flash engines, storing statistics, edits, and classifications dynamically in a local JSON database.

### 1. Requirements
* Node.js (v18 or higher)
* NPM package manager

### 2. Environment Variables Configuration
Create a `.env` file in the root directory:
```env
GEMINI_API_KEY="YOUR_GOOGLE_AI_STUDIO_API_KEY"
PORT=3000
```

### 3. Installation & Run
From the root directory, execute:
```bash
# Install NPM packages
npm install

# Live Development Mode (starts custom server.ts taking Vite middleware)
npm run dev

# Compile Production Build packages
npm run build

# Start Standalone Production Server
npm start
```

Your server will boot and serve traffic at `http://localhost:3000`.

---

## Part B: Offline ML model training with Python & TensorFlow

The `/ml_model/` folder contains standalone training and prediction modules using OpenCV and Tensor convolutional layers.

### 1. Requirements
Ensure you have Python 3.8 - 3.11 installed.

### 2. Standard Package Installation
Navigate to the ML folder and install required libraries:
```bash
cd ml_model
pip install -r requirements.txt
```

### 3. Organizing the Training Dataset
Create subdirectories inside `dataset/` for each classified monument. Place sample photographs inside their respective folder:
```text
dataset/
│
├── Taj Mahal/
│   ├── taj1.jpg
│   └── taj2.png
│
├── Eiffel Tower/
│   ├── eiffel1.jpg
│   └── eiffel2.jpg
│
└── [Other classes...]
```

### 4. Training the CNN Network Model
Execute the training script to configure deep layers, apply image augmentations, and save the binary model weights:
```bash
python train_model.py
```
This runs backpropagation passes and saves optimized parameters to `monument_model.h5`.

### 5. Running Prediction on Photographic Files
Feed any image file path to `predict.py` using command parameters:
```bash
python predict.py "/path/to/test_photo.jpg"
```
The console will print out the best match class name and model classification confidence score!
